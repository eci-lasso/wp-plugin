<h2><?php echo esc_html(__('Lasso', 'lb-plugin-strings')); ?></h2>

<?php
    if(!$count_projects && !$form_properties['lasso']['project_id']) echo '<a href="'.$this->menu_page_url(['action' => 'setup']).'">'.esc_html(__('You need to link at least one Lasso project...', 'lb-plugin-strings')).'</a>';
    else if($form_properties['lasso']['project_id']) echo '<input type="hidden" name="wpcf7-lasso[project_id]" value="'.$form_properties['lasso']['project_id'].'" />';
?>
<table class="form-table lasso-form-settings" role="presentation">
    <tbody>
        <?php
        if(($count_projects > 1) && !$form_properties['lasso']['project_id']) {
            $plugin_settings = $this->lasso_setting();
            uasort($plugin_settings, function($project_a, $project_b) {
                return strcmp($project_a['project_name'], $project_b['project_name']);
            });
        ?>
        <tr>
            <th scope="row" style="white-space: nowrap;">
                <?php echo __('Link your form to a Lasso project:', 'lb-plugin-strings'); ?>
            </th>
            <td>
                <div class="lasso-project-picker">
                    <select name="wpcf7-lasso[project_id]">
                    <?php
                        foreach($plugin_settings as $project_id => $settings) {
                            echo '<option value="'.$project_id.'"'.(($form_properties['lasso']['project_id'] == $project_id) ? ' selected' : '').'>'.$settings['project_name'].'</option>';
                        }
                    ?>
                    </select>
                </div>
            </td>
        </tr>
        <?php
        } else {
            foreach($form_properties['lasso'] as $setting_id => $setting_value) {
                if(($setting_id == 'api_key') || ($setting_id == 'skip_mail') || ($setting_id == 'legacy_mode') || ($setting_id == 'project_id') || ($setting_id == 'project_name')) continue;
                $lasso_field_info = $this->lasso_field_info($form_properties['lasso']['project_id'], $setting_id);
        ?>
        <tr>
            <th scope="row" style="white-space: nowrap;">
                <?php echo esc_html($lasso_field_info['label']); ?>
            </th>
            <td>
                <?php echo $this->html_for_setting($form_properties['lasso']['project_id'], $setting_id, $setting_value, $lasso_field_info); ?>
            </td>
        </tr>
        <?php
            }
        ?>
        <tr>
            <th scope="row" style="white-space: nowrap;">
                <?php echo esc_html(__('ContactForm7 email')); ?>
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"></legend>
                    <label for="wpcf7-lasso-skip-mail">
                        <input type="checkbox" name="wpcf7-lasso-skip-mail" id="wpcf7-lasso-skip-mail" value="1"<?php echo !!$form_properties['lasso']['skip_mail'] ? ' checked="checked"' : ''; ?>> Do not send
                    </label>
                </fieldset>
            </td>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table>

