<?php
if(!class_exists('GFForms')) die();

class LB_GF_PhoneType_Field extends LB_GF_Select_Field {
    use LassoGravityFormField;

    public $type = 'lb_phoneType';
    public $inputType = 'select';
    public $inputName = 'phoneType';

    public function get_form_editor_field_title() {
        return esc_attr__('Phone Type', 'lb-plugin-strings');
    }
    protected function form_editor_inline_script_content($lasso_field_info, &$function_lines, $project_id) {
        parent::form_editor_inline_script_content($lasso_field_info, $function_lines, $project_id);
        $function_lines[] = 'field.defaultValue = "'.$lasso_field_info['options'][0]['id'].'";';
        $function_lines[] = 'field.isHidden = true;';
        $function_lines[] = 'field.visibility = "hidden";';
    }
}
GF_Fields::register(new LB_GF_PhoneType_Field());
