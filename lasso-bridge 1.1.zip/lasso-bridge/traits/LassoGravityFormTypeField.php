<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoGravityFormField.php');

trait LassoGravityFormTypeField {
    use LassoGravityFormField;

    protected $field_info_id;
    protected $field_info_type_id;

    private function type_choices() {
        $form = $this->get_current_form();
        $form_properties = GFFormsModel::get_form_meta($form['id']);
        $this->lasso_auto_assign_project_id($form_properties);
        $lasso_field_info = $this->lasso_field_info($form_properties['project_id'], $this->field_info_type_id);
        $choices = [];
        foreach($lasso_field_info['options'] as $option) {
            $choices[] = [
                'value' => $option['id'],
                'text' => $option['name']
            ];
        }
        return $choices;
    }
    public function sanitize_settings_choices( $choices = null ) {
        $choices = parent::sanitize_settings_choices($choices);
        if(!empty($choices)) $choices = $this->type_choices();
        return $choices;
    }
	public function get_name_prefix_field($input, $id, $field_id, $value, $disabled_text, $tabindex) {
		$autocomplete = $this->enableAutocomplete ? $this->get_input_autocomplete_attribute($input) : '';
		$aria_attributes = $this->get_aria_attributes(array($input['id'] => $value), '3');
		$describedby_attribute = $this->get_aria_describedby();

		if(isset($input['choices']) && is_array($input['choices'])) {
			$placeholder_value = GFCommon::get_input_placeholder_value($input);
			$options = "<option value=''>{$placeholder_value}</option>";
			$value_enabled = rgar($input, 'enableChoiceValue');
			foreach($input['choices'] as $choice) {
				$choice_value = $value_enabled ? $choice['value'] : $choice['text'];
				$is_selected_by_default = rgar($choice, 'isSelected');
				$is_this_choice_selected = empty($value) ? $is_selected_by_default : strtolower($choice_value) == strtolower($value);
				$selected = $is_this_choice_selected ? "selected='selected'" : '';
				$options .= "<option value='{$choice_value}' {$selected}>{$choice['text']}</option>";
			}

			$markup = "<select name='input_{$id}.3' id='{$field_id}_3' {$tabindex} {$disabled_text} {$autocomplete} {$aria_attributes} {$this->maybe_add_aria_describedby($input, $field_id, $this['formId'])}>
                          {$options}
                      </select>";
		} else {
			$placeholder_attribute = GFCommon::get_input_placeholder_attribute($input);
			$markup = "<input type='text' name='input_{$id}.3' id='{$field_id}_3' value='{$value}' {$tabindex} {$disabled_text} {$placeholder_attribute} {$autocomplete} {$this->maybe_add_aria_describedby($input, $field_id, $this['formId'])}/>";
		}

		return $markup;
	}
	public function get_field_input( $form, $value = '', $entry = null ) {
		$is_entry_detail = $this->is_entry_detail();
		$is_form_editor = $this->is_form_editor();
		$is_admin = $is_entry_detail || $is_form_editor;

		$form_id = $form['id'];
		$id = intval($this->id);
		$field_id = ($is_entry_detail || $is_form_editor || ($form_id == 0)) ? "input_$id" : 'input_'.$form_id."_$id";
		$form_id = (($is_entry_detail || $is_form_editor) && empty($form_id)) ? rgget('id') : $form_id;

		$class = esc_attr(rgget('view') == 'entry' ? '_admin' : '');

		$disabled_text = $is_form_editor ? "disabled='disabled'" : '';
		$class_suffix = $is_entry_detail ? '_admin' : '';

		$form_sub_label_placement = rgar($form, 'subLabelPlacement');
		$field_sub_label_placement = $this->subLabelPlacement;
		$is_sub_label_above = (($field_sub_label_placement == 'above') || (empty( $field_sub_label_placement) && ($form_sub_label_placement == 'above')));
		$sub_label_class_attribute = ($field_sub_label_placement == 'hidden_label') ? "class='hidden_sub_label screen-reader-text'" : '';

		$field = '';
		$field_index = ($this->type == 'lb_email') ? 1 : 2;
		$fieldType  = '';

		if(is_array($value)) {
			$field = esc_attr(GFForms::get($this->id.'.'.$field_index, $value));
			$fieldType = esc_attr(GFForms::get($this->id.'.3', $value));
		}

        $field_input = GFFormsModel::get_input($this, $this->id.'.'.$field_index);
		$fieldType_input = GFFormsModel::get_input($this, $this->id.'.3');

		$field_placeholder_attribute = GFCommon::get_input_placeholder_attribute($field_input);
		if($fieldType_input) $fieldType_placeholder_attribute = GFCommon::get_input_placeholder_attribute($fieldType_input);
		$fieldType_markup = '';

		$required_attribute = $this->isRequired ? 'aria-required="true"' : '';
		$invalid_attribute = $this->failed_validation ? 'aria-invalid="true"' : 'aria-invalid="false"';
		$describedby_attribute = $this->get_aria_describedby();
		$input_aria_describedby = '';


        $field_aria_attributes  = $this->get_aria_attributes($value, $field_index);
        $fieldType_aria_attributes = $this->get_aria_attributes($value, '3');

		$field_autocomplete = $this->enableAutocomplete ? $this->get_input_autocomplete_attribute($field_input) : '';
		if($fieldType_input) $fieldType_autocomplete  = $this->enableAutocomplete ? $this->get_input_autocomplete_attribute($fieldType_input) : '';

        $field_tabindex = GFCommon::get_tabindex();
        $fieldType_tabindex = GFCommon::get_tabindex();
        $field_sub_label = (rgar($field_input, 'customLabel') != '') ? $field_input['customLabel'] : gf_apply_filters(array('gform_field_address', $form_id), $this->subLabelValue, $form_id);
        if($fieldType_input) $fieldType_sub_label  = (rgar($fieldType_input, 'customLabel') != '') ? $fieldType_input['customLabel'] : gf_apply_filters(array('gform_field_type', $form_id ), esc_html__('Type', 'lb-plugin-strings'), $form_id);
        if($is_sub_label_above) {
            $field_markup = '';
            $style = ($is_admin && rgar($field_input, 'isHidden')) ? "style='display:none;'" : '';
            if($is_admin || !rgar( $field_input, 'isHidden')) {
                $field_markup = "<span id='{$field_id}_".$field_index."_container' class='field_address' {$style}>
                                    <label for='{$field_id}_".$field_index."' {$sub_label_class_attribute}>{$field_sub_label}</label>
                                    <input type='text' name='input_{$id}.".$field_index."' id='{$field_id}_".$field_index."' value='{$field}' {$field_tabindex} {$disabled_text} {$field_aria_attributes} {$field_placeholder_attribute} />
                                </span>";
            }

            if($fieldType_input) {
				$style = ($is_admin && rgar($fieldType_input, 'isHidden')) ? "style='display:none;'" : '';
				if($is_admin || !rgar($fieldType_input, 'isHidden')) {
					$fieldType_select_class = isset($fieldType_input['choices']) && is_array($fieldType_input['choices']) ? 'name_prefix_select' : '';
					$fieldType_markup = $this->get_name_prefix_field($fieldType_input, $id, $field_id, $fieldType, $disabled_text, $fieldType_tabindex);
					$fieldType_markup = "<span id='{$field_id}_3_container' class='field_type {$fieldType_select_class}' {$style}>
											<label for='{$field_id}_3' {$sub_label_class_attribute}>{$fieldType_sub_label}</label>
											{$fieldType_markup}
											</span>";
				}
            }
        } else {
            $field_markup = '';
            $style = ($is_admin && rgar($field_input, 'isHidden')) ? "style='display:none;'" : '';
            if($is_admin || !rgar($field_input, 'isHidden')) {
                $field_markup = "<span id='{$field_id}_".$field_index."_container' class='field_address' {$style}>
                                    <input type='text' name='input_{$id}.".$field_index."' id='{$field_id}_".$field_index."' value='{$field}' {$field_tabindex} {$disabled_text} {$field_aria_attributes} {$field_placeholder_attribute} />
                                    <label for='{$field_id}_".$field_index."' {$sub_label_class_attribute}>{$field_sub_label}</label>
                                </span>";
            }

            if($fieldType_input)  {
				$style = ($is_admin && rgar($fieldType_input, 'isHidden')) ? "style='display:none;'" : '';
				if($is_admin || !rgar($fieldType_input, 'isHidden')) {
					$fieldType_select_class = isset($fieldType_input['choices']) && is_array($fieldType_input['choices']) ? 'name_prefix_select' : '';
					$fieldType_markup = $this->get_name_prefix_field($fieldType_input, $id, $field_id, $fieldType, $disabled_text, $fieldType_tabindex);
					$fieldType_markup = "<span id='{$field_id}_3_container' class='field_type {$fieldType_select_class}' {$style}>
											{$fieldType_markup}
											<label for='{$field_id}_3' {$sub_label_class_attribute}>{$fieldType_sub_label}</label>
											</span>";
				}
            }
        }

        $css_class = $this->get_css_class();

        return "<div class='ginput_complex{$class_suffix} ginput_container {$css_class}' id='{$field_id}'>
                    {$field_markup}
                    {$fieldType_markup}
                    <div class='gf_clear gf_clear_complex'></div>
                </div>";
	}
    protected function form_editor_inline_script_content($lasso_field_info, &$function_lines, $project_id) {
        parent::form_editor_inline_script_content($lasso_field_info, $function_lines, $project_id);
        $function_lines[] = 'field.defaultValue = "'.$lasso_field_info['options'][0]['value'].'";';
        $function_lines[] = 'field.isHidden = true;';
        $function_lines[] = 'field.visibility = "hidden";';
    }
	public function get_css_class() {
		$field_index = ($this->type == 'lb_email') ? 1 : 2;
		$field_input = GFFormsModel::get_input($this, $this->id.'.'.$field_index);
		$fieldType_input = GFFormsModel::get_input($this, $this->id.'.3');

		$css_class = '';
		$visible_input_count = 0;

		if($field_input && !rgar($field_input, 'isHidden')) {
			$visible_input_count++;
			$css_class .= 'has_'.$this->field_info_id.' ';
		} else {
			$css_class .= 'no_'.$this->field_info_id.' ';
		}
		if($fieldType_input && !rgar($fieldType_input, 'isHidden')) {
			$visible_input_count++;
			$css_class .= 'has_'.$this->field_info_id.'_type ';
		} else {
			$css_class .= 'no_'.$this->field_info_id.'_type ';
		}

		$css_class .= "gf_{$this->field_info_id}_has_{$visible_input_count} ginput_container_{$this->field_info_id} ";

		return trim( $css_class );
	}
	function validate($value, $form) {
		if($this->isRequired) {
			$message = $this->complex_validation_message($value, $this->get_required_inputs_ids());
			if($message) {
				$this->failed_validation = true;
				$message_intro = empty($this->errorMessage) ? __('This field is required.', 'gravityforms') : $this->errorMessage;
				$this->validation_message = $message_intro.' '.$message;
			}
		}
	}
}
