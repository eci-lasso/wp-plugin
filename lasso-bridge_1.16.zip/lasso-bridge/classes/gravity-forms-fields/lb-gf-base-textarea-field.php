<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoGravityFormField.php');

class LB_GF_Textarea_Field extends GF_Field_Textarea {
    use LassoGravityFormField;

    public $type = 'lb_textarea';
    // $this->inputName

    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted textarea field to send to Lasso', 'lb-plugin-strings');
    }
}
