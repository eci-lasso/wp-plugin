<?php
if(!class_exists('GFForms')) die();

class LB_GF_Phone_Field extends GF_Field_Phone {
    use LassoGravityFormField;

    public $type = 'lb_phone';
    public $inputType = 'phone';
    public $inputName = 'phone';

    public function get_form_editor_field_title() {
        return esc_attr__('Phone', 'lb-plugin-strings');
    }
    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted phone field to send to Lasso', 'lb-plugin-strings');
    }
}
GF_Fields::register(new LB_GF_Phone_Field());
