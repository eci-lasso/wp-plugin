<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoSettings.php');

trait LassoGravityFormField {
    use LassoSettings;

    protected function form_project_id() {
        $form_id = $this->get_current_form_id();
        $feeds = GFAPI::get_feeds(null, $form_id, 'lassobridgeaddon');
        if(!is_wp_error($feeds) && !empty($feeds)) {
            $feed = $feeds[0];
            if($feed && isset($feed['meta']) && isset($feed['meta']['project_id']) && $feed['meta']['project_id']) return $feed['meta']['project_id'];
        }
        return 0;
    }
    protected function get_current_form_id() {
        if(!rgempty('id', $_GET)) return rgget('id');
        return 0;
    }
    protected function get_current_form() {
        $form_id = $this->get_current_form_id();
        if($form_id) {
            return LB_Plugin::object_cache_get('gf-form-'.$form_id, function() use($form_id) { return GFAPI::get_form($form_id); });
        }
        return null;
    }
    public function get_form_editor_button() {
        $form_id = $this->get_current_form_id();
        $feeds = GFAPI::get_feeds(null, $form_id, 'lassobridgeaddon');
        if(empty($feeds) || is_wp_error($feeds)) return [];
        return array(
            'group' => LassoGravityFormsAddOn::GROUP_NAME,
            'text'  => $this->get_form_editor_field_title()
        );
    }
    public function add_button($field_groups) {
        $feeds = GFAPI::get_feeds(null, null, 'lassobridgeaddon');
        if(is_wp_error($feeds) || empty($feeds)) return $field_groups; // define your feed first...
        $lasso_field_group = null;
        foreach($field_groups as $field_group) {
            if($field_group['name'] == LassoGravityFormsAddOn::GROUP_NAME) {
                $lasso_field_group = $field_group;
                break;
            }
        }
        if(!$lasso_field_group) {
            array_unshift($field_groups, [
                'name' => LassoGravityFormsAddOn::GROUP_NAME,
                'label' => __('Lasso Fields', 'lb-plugin-strings'),
                'fields' => array()
            ]);    
        }
        return parent::add_button($field_groups);
    }
    /*
    public function get_field_input($form, $value='', $entry=null) {
        // flag form so it will issue analytics js
        return parent::get_field_input($form, $value, $entry);
    }
    */
    protected function form_editor_inline_script_content($lasso_field_info, &$function_lines, $project_id) {
    }
    public function get_form_editor_inline_script_on_page_render() {
        $project_id = $this->form_project_id();
        $field_id = $this->inputName;
        $lasso_field_info = $this->lasso_field_info($project_id, $field_id);

        $script = sprintf('function SetDefaultValues_%s(field) {', $this->type);
        $function_lines = [
            'field.label = "'.$lasso_field_info['label'].'";'
        ];
        $this->form_editor_inline_script_content($lasso_field_info, $function_lines, $project_id);
        $script .= implode('', $function_lines).' }';
        return $script;
    }
}
