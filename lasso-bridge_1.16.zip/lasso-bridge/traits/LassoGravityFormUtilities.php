<?php
if(!class_exists('GFForms')) die();

trait LassoGravityFormUtilities {
    private function gf_object_cache_key($key) {
        return 'gf-'.$key;
    }
    protected function gf_object_cache_get($key, $default = null) {
        // $default can be a value OR a funciton that returns the default value ; the default WILL be cached!
        $key = $this->gf_object_cache_key($key);
        $found = false;
        $value = wp_cache_get($key, 'default', false, $found);
        if(!$found) {
            if(is_callable($default)) $value = $default();
			else $value = $default;
            if(!is_wp_error($value)) $this->gf_object_cache_set($key, $value);
        }
        return $value;
    }
    protected function gf_object_cache_set($key, $value) {
        wp_cache_set($this->gf_object_cache_key($key), $value);
    }
}
