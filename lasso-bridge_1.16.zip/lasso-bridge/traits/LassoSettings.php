<?php
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoAPI.php');

trait LassoSettings {
    use LassoAPI;

    protected function upgrade_lasso_settings() {
        if(LB_PLUGIN_VERSION < '1.8') {
            $plugin_settings = get_option(LB_Plugin::SETTINGS_NAME, []);
            if(!empty($plugin_settings)) {
                foreach($plugin_settings as $project_id => &$settings) {
                    if(!array_key_exists('websiteTracking', $settings)) {
                        $settings['websiteTracking'] = $this->lasso_field_info($project_id, 'websiteTracking')['default_value'];
                    }
                }
                update_option(LB_Plugin::SETTINGS_NAME, $plugin_settings);
            }    
        }
    }
    protected function mask_value($text, $right=0, $left=0) {
        // inspired from wpcf7_mask_password
        $length = strlen($text);

        $right = absint($right);
        $left = absint($left);
    
        if($length < ($right + $left)) {
            $right = 0;
            $left = 0;
        }
    
        $mask_length = max(4, ($length <= 48) ? $length : 48);
        $mask = str_repeat('*', $mask_length);
    
        $left_unmasked = $left ? substr($text, 0, $left) : '';
        $right_unmasked = $right ? substr($text, -1 * $right) : '';
    
        return $left_unmasked.$mask .$right_unmasked;
    }
    protected function lasso_project($project_id, $api_key = null) {
        global $lb_plugin;
        return $lb_plugin->lasso_project($project_id, $api_key);
    }
    protected function lasso_setting_save($project_id, $settings) {
        if(!$project_id) delete_option(LB_Plugin::SETTINGS_NAME);
        else {
            $plugin_settings = get_option(LB_Plugin::SETTINGS_NAME, []);
            if(empty($plugin_settings)) $plugin_settings = [];
            if(!empty($settings)) $plugin_settings[$project_id] = $settings;
            else if(array_key_exists($project_id, $plugin_settings)) unset($plugin_settings[$project_id]);
            update_option(LB_Plugin::SETTINGS_NAME, $plugin_settings);
        }
    }
    protected function lasso_setting($project_id = null, $name='') {
        $default_settings = function() use ($project_id) {
            return [
                'api_key' => '',
                'project_id' => 0,
                'project_name' => '',
                'websiteTracking' => $this->lasso_field_info($project_id, 'websiteTracking')['default_value'],
                'rotationId' => $this->lasso_field_info($project_id, 'rotationId')['default_value'],
                'thankYouEmailTemplateId' => $this->lasso_field_info($project_id, 'thankYouEmailTemplateId')['default_value'],
                'assignedSalesReps' => $this->lasso_field_info($project_id, 'assignedSalesReps')['default_value'],
                'sendSalesRepAssignmentNotification' => $this->lasso_field_info($project_id, 'sendSalesRepAssignmentNotification')['default_value'],
                'sendOptInEmail' => $this->lasso_field_info($project_id, 'sendOptInEmail')['default_value'],
                'sourceType' => $this->lasso_field_info($project_id, 'sourceType')['default_value'],
                'secondarySourceType' => $this->lasso_field_info($project_id, 'secondarySourceType')['default_value'],
                'rating' => $this->lasso_field_info($project_id, 'rating')['default_value'],
                'followUpProcess' => $this->lasso_field_info($project_id, 'followUpProcess')['default_value']
            ];
        };

        $plugin_settings = get_option(LB_Plugin::SETTINGS_NAME, []);
        if(!$project_id) {
            if($name) {
                $project = null;
                if(isset($plugin_settings[$name]) && isset($plugin_settings[$name]['api_key'])) $project = $this->lasso_project($name, $plugin_settings[$name]['api_key']);
                return (isset($plugin_settings[$name]) ? $plugin_settings[$name] : $default_settings());
            }
            return $plugin_settings;
        }

        if($plugin_settings && array_key_exists($project_id, $plugin_settings)) $settings = $plugin_settings[$project_id];
        else $settings = $default_settings();

        if(!array_key_exists('assignedSalesReps', $settings)) {
            if(!array_key_exists('salesReps', $settings)) $settings['assignedSalesReps'] = $this->lasso_field_info($project_id, 'assignedSalesReps')['default_value'];
            else {
                $settings['assignedSalesReps'] = $settings['salesReps'];
                unset($settings['salesReps']);
            } 
        }

        if($name) $settings = (isset($settings[$name]) ? $settings[$name] : '');

        return $settings;
    }
    protected function lasso_auto_assign_project_id(&$form_settings) {
        $project_count = 0;
        if(!isset($form_settings['project_id'])) {
            $plugin_settings = $this->lasso_setting();
            if(!$plugin_settings) $form_settings['project_id'] = 0;
            else {
                $project_count = count($plugin_settings);
                if($project_count == 1) $form_settings['project_id'] = array_key_first($plugin_settings);
                else $form_settings['project_id'] = 0;
            }
        }
        return $project_count;
    }
    protected function lasso_field_info($project_id = null, $setting_id = '', $lasso_project = null) {
        $info = [
            'default_label' => '',
            'label' => '',
            'option' => [ 'value' => 'id', 'name' => 'name' ],
            'options' => [],
            'description' => '',
            'tag' => 'input',
            'default_display_as' => null,
            'question_id' => null
        ];
        if(!$lasso_project) $lasso_project = $project_id ? $this->lasso_project($project_id) : null;
        $setting_id = preg_replace('/.+\[([^\]]+)\]/', '$1', $setting_id);

        switch($setting_id) {
            case 'legacy_mode':
            break;
            
            // settings with defaults
            case 'websiteTracking':
                $info['default_label'] = __('Website Tracking', 'lb-plugin-strings');
                $info['default_value'] = '';
                if(!!$lasso_project) {
                    if(count($lasso_project->websiteTracking) > 1) {
                        $domain = parse_url(get_site_url(), PHP_URL_HOST);
                        foreach($lasso_project->websiteTracking as $tracking) {
                            if($tracking->domain && (strpos($tracking->domain, $domain) !== false)) {
                                $info['default_value'] = $tracking->domainAccountId;
                                break;
                            }
                        }
                    }
                    if(!$info['default_value'] && !empty($lasso_project->websiteTracking)) $info['default_value'] = $lasso_project->websiteTracking[0]->domainAccountId;
                }
                $info['label'] = __('Website Tracking', 'lb-plugin-strings');
                $info['option'] = [ 'value' => 'domainAccountId', 'name' => 'domain' ];
                $info['options'] = $lasso_project ? $lasso_project->websiteTracking : [];
                $info['description'] = __('The analytics code to use on the current site. See Project Admin > Project Setup > Website Analytics on https://app.lassocrm.com/', 'lb-plugin-strings');
                $info['tag'] = 'select';
                $info['required'] = true;
            break;
            case 'rotationId':
                $info['default_label'] = __('Default Rotation', 'lb-plugin-strings');
                $info['default_value'] = 0;
                $info['label'] = __('Rotation', 'lb-plugin-strings');
                $info['option'] = [ 'value' => 'rotationId', 'name' => 'rotationName' ];
                $info['options'] = $lasso_project ? $lasso_project->rotations : [];
                $info['description'] = __('Which list of sales people to assign the registrants to', 'lb-plugin-strings');
                $info['tag'] = 'select';
                $info['default_display_as'] = 'hidden';
            break;
            case 'thankYouEmailTemplateId':
                $info['default_label'] = __('Default Auto Reply Email', 'lb-plugin-strings');
                $info['default_value'] = 0;
                $info['label'] = __('Auto Reply Email', 'lb-plugin-strings');
                $info['option'] = [ 'value' => 'templateId', 'name' => 'name' ];
                $info['options'] = $lasso_project ? $lasso_project->autoReplyTemplates : [];
                $info['description'] = __('Email template used by Lasso for auto-reply', 'lb-plugin-strings');
                $info['tag'] = 'select';
            break;
            case 'sendSalesRepAssignmentNotification':
                $info['default_label'] = __('Default Sales Rep Assignment Notification', 'lb-plugin-strings');
                $info['default_value'] = 1;
                $info['label'] = __('Sales Rep Assignment Notification', 'lb-plugin-strings');
                $info['options'] = [
                    [ 'id' => 1, 'name' => __('Send a Notification', 'lb-plugin-strings') ]
                ];
                $info['description'] = __('Send notification to selected sales rep', 'lb-plugin-strings');
                $info['tag'] = 'checkbox';
            break;
            case 'sendOptInEmail':
                $info['default_label'] = __('Default Opt-in Email', 'lb-plugin-strings');
                $info['default_value'] = 1;
                $info['label'] = __('Opt-in Email', 'lb-plugin-strings');
                $info['options'] = [
                    [ 'id' => 1, 'name' => __('Send email', 'lb-plugin-strings') ]
                ];
                $info['description'] = __('Send an opt-in email to new registrants', 'lb-plugin-strings');
                $info['tag'] = 'checkbox';
            break;
            case 'assignedSalesReps':
                $info['default_label'] = __('Default Sale Reps', 'lb-plugin-strings');
                $info['default_value'] = [];
                $info['label'] = __('Sale Reps', 'lb-plugin-strings');
                $info['option'] = [ 'value' => 'userId', 'name' => 'email' ];
                $info['options'] = $lasso_project ? $lasso_project->salesReps : [];
                $info['tag'] = 'multi_select';
            break;
            case 'sourceType':
                $info['default_label'] = __('Default Source Type', 'lb-plugin-strings');
                $info['default_value'] = 0;
                $info['label'] = __('Source Type', 'lb-plugin-strings');
                // $info['option'] = [ 'value' => 'sourceTypeId', 'name' => 'sourceType' ];
                $info['option'] = [ 'value' => 'sourceType', 'name' => 'sourceType' ];
                $info['options'] = $lasso_project ? $lasso_project->sourceTypes : [];
                $info['tag'] = 'select';
                $info['default_display_as'] = 'hidden';
            break;
            case 'secondarySourceType':
                $info['default_label'] = __('Default Secondary Source Type', 'lb-plugin-strings');
                $info['default_value'] = 0;
                $info['label'] = __('Secondary Source Type', 'lb-plugin-strings');
                // $info['option'] = [ 'value' => 'secondarySourceTypeId', 'name' => 'secondarySourceType' ];
                $info['option'] = [ 'value' => 'secondarySourceType', 'name' => 'secondarySourceType' ];
                $info['options'] = $lasso_project ? $lasso_project->secondarySourceTypes : [];
                $info['tag'] = 'select';
                $info['default_display_as'] = 'hidden';
            break;
            case 'rating':
                $info['default_label'] = __('Default Rating', 'lb-plugin-strings');
                $info['default_value'] = 0;
                $info['label'] = __('Rating', 'lb-plugin-strings');
                // $info['option'] = [ 'value' => 'ratingId', 'name' => 'rating' ];
                $info['option'] = [ 'value' => 'rating', 'name' => 'rating' ];
                $info['options'] = $lasso_project ? $lasso_project->ratings : [];
                $info['tag'] = 'select';
                $info['default_display_as'] = 'hidden';
            break;
            case 'followUpProcess':
                $info['default_label'] = __('Default Follow up process', 'lb-plugin-strings');
                $info['default_value'] = 0;
                $info['label'] = __('Follow up process', 'lb-plugin-strings');
                $info['option'] = [ 'value' => 'followUpProcessId', 'name' => 'followUpProcess' ];
                $info['options'] = $lasso_project ? $lasso_project->followUpProcesses : [];
                $info['tag'] = 'select';
            break;

            // lasso common info fields
            case 'firstName':
                $info['label'] = __('First Name', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'lastName':
                $info['label'] = __('Last Name', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'nameTitle':
                $info['label'] = __('Title', 'lb-plugin-strings');
                $info['options'] = [
                    [ 'id' => 'Dr', 'name' => 'Dr' ],
                    [ 'id' => 'Mr', 'name' => 'Mr' ],
                    [ 'id' => 'Mrs', 'name' => 'Mrs' ],
                    [ 'id' => 'Mr & Mrs', 'name' => 'Mr & Mrs' ],
                    [ 'id' => 'Ms', 'name' => 'Ms' ],
                    [ 'id' => 'Miss', 'name' => 'Miss' ],
                    [ 'id' => 'Lord', 'name' => 'Lord' ]
                ];
                $info['tag'] = 'select';
            break;
            case 'nameBlock':
                $info['label'] = __('Full Name', 'lb-plugin-strings');
                $name_titles = $this->lasso_field_info($project_id, 'nameTitle');
                $info['options'] = $name_titles['options'];
                $info['tag'] = 'full-name';
            break;
            case 'address':
                $info['label'] = __('Address', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'city':
                $info['label'] = __('City', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'addressBlock':
                $info['label'] = __('Full Address', 'lb-plugin-strings');
                $info['options'] = [
                    [ 'name' => 'Alberta', 'id' => 'AB', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'British Columbia', 'id' => 'BC', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Manitoba', 'id' => 'MB', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'New Brunswick', 'id' => 'NB', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Newfoundland and Labrador', 'id' => 'NL', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Northwest Territories', 'id' => 'NT', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Nova Scotia', 'id' => 'NS', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Nunavut', 'id' => 'NU', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Ontario', 'id' => 'ON', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Prince Edward Island', 'id' => 'PE', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Quebec', 'id' => 'QC', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Saskatchewan', 'id' => 'SK', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Yukon Territory', 'id' => 'YT', 'group' => __('Canada', 'lb-plugin-strings') ],
                    [ 'name' => 'Alabama', 'id' => 'AL', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Alaska', 'id' => 'AK', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'American Samoa', 'id' => 'AS', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Arizona', 'id' => 'AZ', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Arkansas', 'id' => 'AR', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'California', 'id' => 'CA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Colorado', 'id' => 'CO', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Connecticut', 'id' => 'CT', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Delaware', 'id' => 'DE', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'District of Columbia', 'id' => 'DC', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'States of Micronesia', 'id' => 'FM', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Florida', 'id' => 'FL', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Georgia', 'id' => 'GA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Guam', 'id' => 'GU', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Hawaii', 'id' => 'HI', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Idaho', 'id' => 'ID', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Illinois', 'id' => 'IL', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Indiana', 'id' => 'IN', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Iowa', 'id' => 'IA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Kansas', 'id' => 'KS', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Kentucky', 'id' => 'KY', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Louisiana', 'id' => 'LA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Maine', 'id' => 'ME', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Marshall Islands', 'id' => 'MH', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Maryland', 'id' => 'MD', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Massachusetts', 'id' => 'MA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Michigan', 'id' => 'MI', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Minnesota', 'id' => 'MN', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Mississippi', 'id' => 'MS', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Missouri', 'id' => 'MO', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Montana', 'id' => 'MT', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Nebraska', 'id' => 'NE', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Nevada', 'id' => 'NV', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'New Hampshire', 'id' => 'NH', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'New Jersey', 'id' => 'NJ', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'New Mexico', 'id' => 'NM', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'New York', 'id' => 'NY', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'North Carolina', 'id' => 'NC', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'North Dakota', 'id' => 'ND', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Northern Mariana Islands', 'id' => 'MP', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Ohio', 'id' => 'OH', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Oklahoma', 'id' => 'OK', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Oregan', 'id' => 'OR', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Palau', 'id' => 'PW', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Pennsilvania', 'id' => 'PA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Puerto Rico', 'id' => 'PR', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Rhode Island', 'id' => 'RI', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'South Carolina', 'id' => 'SC', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'South Dakota', 'id' => 'SD', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Tennessee', 'id' => 'TN', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Texas', 'id' => 'TX', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Utah', 'id' => 'UT', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Vermont', 'id' => 'VT', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Virgin Islands', 'id' => 'VI', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Virginia', 'id' => 'VA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Washington', 'id' => 'WA', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'West Virginia', 'id' => 'WV', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Wisconsin', 'id' => 'WI', 'group' => __('United States', 'lb-plugin-strings') ],
                    [ 'name' => 'Wyoming', 'id' => 'WY', 'group' => __('United States', 'lb-plugin-strings') ]
                ];
                $info['tag'] = 'full-address';
            break;
            case 'state':
                $info['label'] = __('State/Province', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'zipCode':
            case 'postalCode':
                $info['label'] = __('Postal/Zip Code', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'country':
                $info['label'] = __('Country', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'addressType':
                $info['label'] = __('Address Type', 'lb-plugin-strings');
                $info['default_value'] = 'Home';
                $info['options'] = [
                    [ 'id' => 'Home', 'name' => __('Home', 'lb-plugin-strings') ],
                    [ 'id' => 'Work', 'name' => __('Work', 'lb-plugin-strings') ],
                    [ 'id' => 'Other', 'name' => __('Other', 'lb-plugin-strings') ]
                ];
                $info['tag'] = 'select';
                $info['default_display_as'] = 'hidden';
            break;
            case 'company':
                $info['label'] = __('Company', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'ssnSin':
                $info['label'] = __('SIN', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'contactPreference':
                $info['label'] = __('Contact Preference', 'lb-plugin-strings');
                $info['default_value'] = 'noPreference';
                $info['options'] = [
                    [ 'id' => 'noPreference', 'name' => __('No Preference', 'lb-plugin-strings') ],
                    [ 'id' => 'any', 'name' => __('Any', 'lb-plugin-strings') ],
                    [ 'id' => 'email', 'name' => __('Email', 'lb-plugin-strings') ],
                    [ 'id' => 'mail', 'name' => __('Mail', 'lb-plugin-strings') ],
                    [ 'id' => 'phone', 'name' => __('Phone', 'lb-plugin-strings') ],
                    [ 'id' => 'text', 'name' => __('Text', 'lb-plugin-strings') ],
                    [ 'id' => 'noEmail', 'name' => __('No Email', 'lb-plugin-strings') ],
                    [ 'id' => 'noContact', 'name' => __('No Contact', 'lb-plugin-strings') ]
                ];
                $info['tag'] = 'select';
            break;
            case 'gender':
                $info['label'] = __('Gender', 'lb-plugin-strings');
                $info['default_value'] = 'unspecified';
                $info['options'] = [
                    [ 'id' => 'unspecified', 'name' => __('Rather not say', 'lb-plugin-strings') ],
                    [ 'id' => 'male', 'name' => __('Male', 'lb-plugin-strings') ],
                    [ 'id' => 'female', 'name' => __('Female', 'lb-plugin-strings') ]
                ];
                $info['tag'] = 'select';
            break;
            case 'phone':
                $info['label'] = __('Phone', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'phoneType':
                $info['label'] = __('Phone Type', 'lb-plugin-strings');
                $info['default_value'] = 'Mobile';
                $info['options'] = [
                    [ 'id' => 'Home', 'name' => __('Home', 'lb-plugin-strings') ],
                    [ 'id' => 'Work', 'name' => __('Work', 'lb-plugin-strings') ],
                    [ 'id' => 'Mobile', 'name' => __('Mobile', 'lb-plugin-strings') ],
                    [ 'id' => 'Other', 'name' => __('Other', 'lb-plugin-strings') ]
                ];
                $info['tag'] = 'select';
                $info['default_display_as'] = 'hidden';
            break;
            case 'phoneBlock':
                $info['label'] = __('Phone', 'lb-plugin-strings');
                $types = $this->lasso_field_info($project_id, 'phoneType');
                $info['options'] = $types['options'];
                $info['tag'] = 'phone';
            break;
            case 'email':
                $info['label'] = __('Email', 'lb-plugin-strings');
                $info['tag'] = 'input';
            break;
            case 'emailType':
                $info['label'] = __('Email Type', 'lb-plugin-strings');
                $info['default_value'] = 'Work';
                $info['options'] = [
                    [ 'id' => 'Home', 'name' => __('Home', 'lb-plugin-strings') ],
                    [ 'id' => 'Work', 'name' => __('Work', 'lb-plugin-strings') ],
                    [ 'id' => 'Personal', 'name' => __('Personal', 'lb-plugin-strings') ],
                    [ 'id' => 'Other', 'name' => __('Other', 'lb-plugin-strings') ]
                ];
                $info['tag'] = 'select';
                $info['default_display_as'] = 'hidden';
            break;
            case 'emailBlock':
                $info['label'] = __('Email', 'lb-plugin-strings');
                $types = $this->lasso_field_info($project_id, 'emailType');
                $info['options'] = $types['options'];
                $info['tag'] = 'email';
            break;
            case 'notes': // history
                $info['label'] = __('Comments', 'lb-plugin-strings');
                $info['tag'] = 'textarea';
            break;

            // site-specific questions
            default:
                $questions = $lasso_project ? $lasso_project->questions : [];
                if(!empty($questions) && is_array($questions)) {
                    $question_ids = array_column($questions, 'questionId') ;
                    $index = array_search(preg_replace('/^(?:Q|question(?:_-))/i', '', $setting_id), $question_ids);
                    if($index >= 0) {
                        $question = $questions[$index];
                        $info['label'] = $question->name;
                        if(!$info['label']) $info['label'] = 'Question '.$question->questionId;
                        $info['question_id'] = $question->questionId;
                        switch($question->type) {
                            case 'Checkbox':
                            case 'checkbox':
                            case 'Checkboxes':
                            case 'checkboxes':
                                $info['tag'] = 'checkbox';
                                $info['option'] = [ 'value' => 'answerId', 'name' => 'answer' ];
                                $info['options'] = $question->answers;
                                /*
                                $info['options'] = [
                                    [ 'id' => empty($question->answers) ? true : $question->answers[0]->answerId, 'name' => empty($question->answers) ? '' : $question->answers[0]->answer ]
                                ];
                                */
                            break;
                            case 'RadioButtons':
                            case 'Radio Buttons':
                            case 'radio_buttons':
                                $info['tag'] = 'radio';
                                $info['option'] = [ 'value' => 'answerId', 'name' => 'answer' ];
                                $info['options'] = $question->answers;
                            break;
                            case 'Date':
                            case 'date':
                                $info['tag'] = 'date';
                            break;
                            case 'SingleSelect':
                            case 'Single Select':
                            case 'single_select':
                                $info['tag'] = 'select';
                                $info['option'] = [ 'value' => 'answerId', 'name' => 'answer' ];
                                $info['options'] = $question->answers;
                            break;
                            case 'MultiSelect':
                            case 'Multi Select':
                            case 'multi_select':
                                $info['tag'] = 'multi_select';
                                $info['option'] = [ 'value' => 'answerId', 'name' => 'answer' ];
                                $info['options'] = $question->answers;
                            break;
                        }
                        if(!empty($info['options'])) {
                            usort($info['options'], function($option_a, $option_b) use($info) {
                                if(isset($option_a->Position)) {
                                    $comparable_a = intVal($option_a->Position);
                                    $comparable_b = intVal($option_b->Position);
                                    if($comparable_a == $comparable_b) return 0;
                                    return ($comparable_a < $comparable_b) ? -1 : 1;                            
                                }
                                $field = $info['option']['name'];
                                return strcmp($option_a->$field, $option_b->$field);
                            });
                        }
                    }    
                }
            break;
        }
        return $info;
    }
    protected function lasso_fields_sort($project_id, &$fields) {
        usort($fields, function($field_id_a, $field_id_b) use($project_id) {
            $field_a = $this->lasso_field_info($project_id, $field_id_a);
            $field_b = $this->lasso_field_info($project_id, $field_id_b);
            return strcmp($field_a['label'], $field_b['label']);
        });
    }
    protected function lasso_setting_fields($project_id) {
        $fields = ['rotationId', 'thankYouEmailTemplateId', 'assignedSalesReps', 'sendSalesRepAssignmentNotification', 'sendOptInEmail', 'sourceType', 'secondarySourceType', 'rating', 'followUpProcess', 'legacy_mode'];
        $this->lasso_fields_sort($project_id, $fields);
        array_unshift($fields, 'websiteTracking');
        return $fields;
    }
    protected function lasso_form_fields($project_id) {
        $fields = [
            'firstName', 'lastName', 'nameTitle', 'addressBlock', 'address', 'city', 'state', 'zipCode', 'country', 'addressType',
            'company', 'ssnSin', 'contactPreference', 'gender', 'phone', 'phoneType', 'email', 'emailType', 'notes',
            'rotationId','sourceType', 'secondarySourceType', 'rating'
        ];
        $lasso_project = $this->lasso_project($project_id);
        if(!empty($lasso_project->questions)) {
            foreach($lasso_project->questions as $question) $fields[] = $question->questionId;
        }
        $this->lasso_fields_sort($project_id, $fields);
        return $fields;
    }
    protected function set_lasso_settings($project_id, $input) {
        $settings = $this->lasso_setting($project_id);
        foreach($settings as $setting_id => $setting_value) {
            if(($setting_id == 'api_key') || !array_key_exists($setting_id, $input)) continue;
            $settings[$setting_id] = $input[$setting_id];
        }
        $this->lasso_setting_save($project_id, $settings);
    }
    protected function reset_lasso_settings($project_id = null) {
        $this->lasso_setting_save($project_id, null);
    }
    protected function lasso_set_api_key($api_key) {
        $plugin_settings = $this->lasso_setting();
        $api_key_project_id = 0;
        if(!empty($plugin_settings)) {
            foreach($plugin_settings as $project_id => $settings) {
                if($settings['api_key'] === $api_key) {
                    $api_key_project_id = $project_id;
                    break;
                }
            }
        }
        if(!$api_key_project_id) {
            try {
                $lasso_project = $this->lasso_project(null, $api_key);
                if(!$lasso_project->project->projectId) return null;
                $settings = $this->lasso_setting($lasso_project->project->projectId);
                $settings['project_id'] = $lasso_project->project->projectId;
                $settings['api_key'] = $api_key;
                $settings['project_name'] = $lasso_project->project->name;
                $this->lasso_setting_save($lasso_project->project->projectId, $settings);
                return $lasso_project;
            } catch(Exception $exception) {
                return false;
            }
        }
    }
    
    public function is_active() {
        $settings = $this->lasso_setting();
        return !empty($settings) || !$settings['project_id'];
    }
}
?>