(function($) {
    $(function() { 
        var get_field_info = function(field) {
            if(!!window.lasso_form_fields && !!window.lasso_form_fields[field]) return window.lasso_form_fields[field]
            return {}
        };

        $(":input.lasso-value").each(function() {
            var input = $(this);
            var form = input.closest("form");
            var name = input.attr("name")
            if(name && !name.match(/\[\]$/)) {
                var sibblings = form.find(":input[name='" + name + "']");
                if(sibblings.length > 1) sibblings.each(function() { $(this).attr("name", name + "[]") });
            }
        });
       $("select.lasso-address[name^='country']").each(function() {
            var countries_menu = $(this);
            var form = countries_menu.closest("form");
            var states_menu = $("select.lasso-address[name^='state']");
            form.data("_states_menu", states_menu);
            var field_info = get_field_info('addressBlock');
            states_menu.children().each(function() {
                var option = $(this);
                var option_value = option.val();
                var group = ""
                for(var loop = 0; loop < field_info.options.length ; loop++) {
                    if((field_info.options[loop].id === option_value) || (field_info.options[loop].name === option_value)) {
                        group = field_info.options[loop].group
                        break;
                    }
                }
                option.addClass(["lasso-group-member", "lasso-group-" + group.replace(/\s+/, "-")]);
            });
            var change_country = function(country) {
                var states_menu = form.data("_states_menu");
                var country_input = form.data("_country_input");
                var state_input = form.data("_state_input");
                states_menu.children().hide();
                var state_options = states_menu.children().filter(".lasso-group-" + country.replace(/\s+/, "-"));
                if(state_options.show().length) {
                    if(state_input) {
                        state_input.parent().append(states_menu);
                        state_input.detach();
                    }
                    if(country_input) {
                        countries_menu.attr("name", country_input.attr("name")).val(country || country_input.val() || countries_menu.children().first().val());
                        if(country_input) country_input.detach();
                    }
                    states_menu.val(state_options.first().val());
                } else {
                    if(!state_input) {
                        state_input = $('<input type="text" name="' + states_menu.attr("name") + '" value="" />');
                        form.data("_state_input", state_input);
                    }
                    // state_input.val("");
                    states_menu.parent().append(state_input);
                    states_menu.detach();
                    if(!country_input) {
                        country_input = $('<input type="text" name="' + countries_menu.attr("name") + '" value="" />');
                        country_input.on("change", function() {
                            change_country($(this).val());
                        });
                        form.data("_country_input", country_input);
                    }
                    country_input.val("");
                    countries_menu.parent().append(country_input);
                    countries_menu.removeAttr("name");
                }
            };
            countries_menu.on("change", function() {
                change_country(countries_menu.val());
            }).change();
        });
    });
})(jQuery);
