<?php
if(!class_exists('WPCF7_Service')) return;

require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoSettings.php');

class LassoContactFormAddOn extends WPCF7_Service {
    use LassoSettings;

    static private $instance;
    static public function bootstrap() {
        if(defined('WPCF7_VERSION')) {
            $integration = WPCF7_Integration::get_instance();
            $integration->add_service('lasso',
                LassoContactFormAddOn::get_instance()
            );
        }
    }
    static public function get_instance() {
        if(empty(self::$instance)) self::$instance = new self;
        return self::$instance;
    }
    static protected $operators = array('+', '-', '*');

    private $lasso_harvesting_proxy = false;
    private $lasso_proxy = null;
    private $html_snippets = [];
    private $form_output = false;

    private function display_setup() {
        $plugin_settings = $this->lasso_setting();
        include(dirname(__FILE__).'/../templates/contact-form-default-settings.php');
    }
    private $session = array();
			
    private function session_set($key, $data) {
        $key = sanitize_key($key);
    
        if(isset($this->session[$key]) && ($data === null)) unset($this->session[$key]);
        else {
            if(!is_string($data)) $data = maybe_serialize($data);
            $this->session[$key] = $data;
        }
    }
    private function session_get($key, $default='') {
        $key = sanitize_key($key);
        if(!isset($this->session[$key])) return $default;
        return maybe_unserialize($this->session[$key]);
    }
    private function captcha(&$equation) {
        $n1 = rand(1, 10);
        $n2 = rand(1, 10);
        $op = LassoContactFormAddOn::$operators[rand(0, count(LassoContactFormAddOn::$operators) - 1)];
        
        if(($op == '-') || ($op == '/')) {
            $left_number = max($n1, $n2);
            $right_number = min($n1, $n2);
            $n1 = $left_number;
            $n2 = $right_number;
        }
        $equation = number_format($n1, 0).$op.number_format($n2, 0);
    
        switch($op) {
            case '+':
                $result = $n1 + $n2;
                break;
            case '-':
                $result = $n1 - $n2;
                break;
            case '*':
                $result = $n1 * $n2;
                break;
            case '/':
                $result = $n1 / $n2;
                break;
            default:
                $result = null;
                break;
        }
    
        return $result;
    }
    protected function log($url, $request, $response) {
        wpcf7_log_remote_request($url, $request, $response);
    }
    protected function menu_page_url($args = '') {
        $args = wp_parse_args($args, []);

        $url = menu_page_url('wpcf7-integration', false);
        $url = add_query_arg([ 'service' => 'lasso' ], $url);
        if(!empty($args)) $url = add_query_arg($args, $url);

        return $url;
    }
    protected function if_simple_captcha_active($if_callback, $else_callback = null) {
        if(!defined('LASSO_BRIDGE_DISABLE_CF7_EQUATION') || !LASSO_BRIDGE_DISABLE_CF7_EQUATION) return $if_callback();
        if($else_callback) return $else_callback();
    }

    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'maybe_enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'wp_enqueue_scripts'));
        add_action('init', array($this, 'init'));
        add_action('wpcf7_save_contact_form', array($this, 'wpcf7_save_contact_form'), 10, 3);
        add_action('wpcf7_init', array($this, 'wpcf7_init'));
        add_action('wpcf7_admin_init', array($this, 'wpcf7_admin_init'), 19, 0);
        add_action('wpcf7_mail_sent', array($this, 'wpcf7_mail_sent'));

        add_filter('wpcf7_pre_construct_contact_form_properties', array($this, 'wpcf7_pre_construct_contact_form_properties'), 10, 2);
        add_filter('wpcf7_editor_panels', array($this, 'wpcf7_editor_panels'));
        add_filter('wpcf7_form_tag', array($this, 'wpcf7_form_tag'), 99, 2);
        add_filter('wpcf7_posted_data_select', array($this, 'wpcf7_posted_data_types'), 10, 3);
        add_filter('wpcf7_posted_data_select*', array($this, 'wpcf7_posted_data_types'), 10, 3);
        add_filter('wpcf7_posted_data_radio', array($this, 'wpcf7_posted_data_types'), 10, 3);
        add_filter('wpcf7_posted_data_radio*', array($this, 'wpcf7_posted_data_types'), 10, 3);
        add_filter('wpcf7_validate_text', array($this, 'wpcf7_validate_addressBlock'), 1, 2);
        add_filter('wpcf7_validate_text*', array($this, 'wpcf7_validate_addressBlock'), 1, 2);
        $this->if_simple_captcha_active(function() {
            add_filter('wpcf7_validate_solution', array($this, 'wpcf7_solution_validator'), 20, 2);
        });
    }

    public function init() {
        $this->if_simple_captcha_active(function() {
            if(!defined('WP_SESSION_COOKIE')) define('WP_SESSION_COOKIE', 'FormSecure_wp_session');
            $root = dirname(__FILE__);
            if(!class_exists('Recursive_ArrayAccess')) require_once($root.'/class-recursive-arrayaccess.php');
            if(!class_exists('WP_Session')) {
                require_once($root.'/class-wp-session.php');
                require_once($root.'/wp-session.php');
            }
            $this->session = WP_Session::get_instance();
        });
    }
    
    public function wpcf7_posted_data_types($value, $value_orig, $tag) {
// echo 'wpcf7_posted_data_types: value='.print_r($value, true).', value_orig='.print_r($value_orig, true)."\n";
        if(($tag->raw_name == $tag->name) && preg_match('/^(address|email|phone)Type$/', $tag->name)) $value = $value_orig;
        return $value;        
    }
    public function wpcf7_validate_addressBlock($result, $tag) {
// echo 'wpcf7_validate_addressBlock: tag='.print_r($tag->name, true).', result='.print_r($result, true)."\n";
        if($tag->name != 'addressBlock') return $result;
        $tag->type = 'addressBlock';
// echo 'wpcf7_validate_addressBlock: _POST='.print_r($_POST, true)."\n";
        $has_value = (
            (isset($_POST['address']) && !!$_POST['address']) &&
            (isset($_POST['addressType']) && !!$_POST['addressType']) &&
            (isset($_POST['city']) && !!$_POST['city']) &&
            (isset($_POST['state']) && !!$_POST['state']) &&
            (isset($_POST['zipCode']) && !!$_POST['zipCode']) &&
            (isset($_POST['country']) && !!$_POST['country'])
        );
        if($tag->is_required() && !$has_value) $result->invalidate($tag, wpcf7_get_message('invalid_required'));
        else 
    
        return $result;
    }
    public function wpcf7_solution_validator($result, $tag) {
        $tag = new WPCF7_FormTag($tag);
        $solution = $this->session_get('cf7-lasso-solution');
        $user_solution = isset($_POST['cf7-lasso-it-is']) ? $_POST['cf7-lasso-it-is'] : '';
        
        if(($user_solution == '') || ($solution != intVal($user_solution))) $result->invalidate('cf7-lasso-it-is', __('This is not the correct answer to the mathematical question.', 'contact-form-7' ));
        
        return $result;
    }

    public function get_title() {
        return __('Lasso', 'lb-plugin-strings');
    }

    public function get_categories() {
        return ['email-marketing'];
    }
    public function link() {
        echo wpcf7_link('https://www.lassocrm.com/', 'lassocrm.com');
    }
    public function load($action = '') {
        if(('setup' == $action) && ('POST' == $_SERVER['REQUEST_METHOD'])) {
            check_admin_referer('wpcf7-lasso-setup');

            if(isset($_POST['api_key'])) {
                $lasso_project = $this->lasso_set_api_key($_POST['api_key']);
                if($lasso_project) {
                    $redirect_to = $this->menu_page_url([
                        'action' => 'setup',
                        'message' => 'success',
                        'focus' => $lasso_project->project->projectId
                    ]);
                } else if($lasso_project === false) {
                    $redirect_to = $this->menu_page_url([
                        'action' => 'setup',
                        'message' => 'unauthorized'
                    ]);
                } else {
                    $redirect_to = $this->menu_page_url([
                        'action' => 'setup',
                        'message' => 'invalid'
                    ]);
                }
            } else if(isset($_POST['project_id'])) {
                if(!empty($_POST['reset'])) {
                    $this->reset_lasso_settings($_POST['project_id']);
                    $redirect_to = $this->menu_page_url('action=setup');
                } else {
                    $this->set_lasso_settings($_POST['project_id'], $_POST);
                    $redirect_to = $this->menu_page_url([
                        'action' => 'setup'
                    ]);
                }
            }
            wp_safe_redirect($redirect_to);
            exit();
        }
    }
    public function admin_notice($message = '') {
        if($message == 'unauthorized') {
            echo sprintf(
                '<div class="notice notice-error"><p><strong>%1$s</strong>: %2$s</p></div>',
                esc_html(__('Error', 'lb-plugin-strings')),
                esc_html(__('You have not been authenticated. Make sure the provided API key is correct.', 'lb-plugin-strings'))
            );
        }

        if($message == 'invalid') {
            echo sprintf(
                '<div class="notice notice-error"><p><strong>%1$s</strong>: %2$s</p></div>',
                esc_html(__('Error', 'lb-plugin-strings')),
                esc_html(__('Invalid key value.', 'lb-plugin-strings'))
            );
        }

        if($message == 'success') {
            echo sprintf(
                '<div class="notice notice-success"><p>%s</p></div>',
                esc_html(__('Settings saved.', 'lb-plugin-strings'))
            );
        }
    }
	public function display($action = '') {
        echo '<p>'.sprintf(
            esc_html(__('Capture and Nurture All Your Prospects with Lasso CRM, for Home Builders, Real Estate Developers, and New Home Agencies. For details, see %s.', 'lb-plugin-strings')),
            wpcf7_link(
                __('https://www.lassocrm.com/integrations/', 'lb-plugin-strings'),
                __('Lasso integration', 'lb-plugin-strings')
            )
        ).'</p>';

        if($this->is_active()) {
            echo sprintf(
                '<p class="dashicons-before dashicons-yes">%s</p>',
                esc_html( __('Lasso is active on this site.', 'lb-plugin-strings'))
            );
        }

        if($action == 'setup' ) $this->display_setup();
        else {
            echo sprintf(
                '<p><a href="%1$s" class="button">%2$s</a></p>',
                esc_url($this->menu_page_url('action=setup')),
                esc_html(__('Setup integration', 'lb-plugin-strings'))
            );
        }
    }

    public function maybe_enqueue_scripts($hook_suffix) {
        global $lb_plugin;
        if(preg_match('/(wpcf7\-integration|page_wpcf7)/', $hook_suffix)) {
            wp_enqueue_style('lb-plugin-css', $lb_plugin->asset_url('style.css'));
            wp_enqueue_script('lb-plugin-js', $lb_plugin->asset_url('script.js'), array('jquery'));
        }
    }
    public function wp_enqueue_scripts() {
        global $lb_plugin;
        wp_register_script('lb-plugin-frontend-js', $lb_plugin->asset_url('frontend-scripts.js'), array('jquery'));
    }
    public function wpcf7_init() {
        wpcf7_add_form_tag(array('hidden', 'hidden*'), array($this, 'wpcf7_hidden_shortcode_handler'), true);
        wpcf7_add_form_tag(array('equation'), array($this, 'wpcf7_math_equation_shortcode_handler'), false);
        wpcf7_add_form_tag(array('solution'), array($this, 'wpcf7_math_response_shortcode_handler'), true);
        wpcf7_add_form_tag(
            ['lasso', 'lasso*'],
            array($this, 'lasso_form_field'),
            array(
                'name-attr' => true,
            )
         );
    }
    public function wpcf7_admin_init() {
        $tag_generator = WPCF7_TagGenerator::get_instance();
        $tag_generator->add('lasso', __('Lasso', 'lb-plugin-strings'), array($this, 'lasso_field_editor'));
        if(function_exists('wpcf7_add_tag_generator')) {
            wpcf7_add_tag_generator('hidden', __('Hidden field', 'lb-plugin-strings'), 'cf7Lasso-tg-pane-hidden', array($this, 'wpcf7_add_tag_generator'));
            $this->if_simple_captcha_active(function() {
                wpcf7_add_tag_generator('equation', __('Math equation', 'lb-plugin-strings'), 'cf7Lasso-tg-pane-equation', array($this, 'wpcf7_add_equation_tag_generator'));
                wpcf7_add_tag_generator('solution', __('Math response', 'lb-plugin-strings'), 'cf7Lasso-tg-pane-solution', array($this, 'wpcf7_add_solution_tag_generator'));
            });
        }
    }

    public function wpcf7_pre_construct_contact_form_properties($properties, $contact_form) {
        $properties = array_merge($properties, [
            'lasso' => []
        ]);
        return $properties;
    }
    public function wpcf7_editor_panels($panels) {
        $panels['lasso-settings-panel'] = array(
            'title' => __('Lasso Settings', 'lb-plugin-strings'),
            'callback' => array($this, 'lasso_editor_panel')
        );
        return $panels;
    }
    protected function html_for_setting($project_id, $setting_id, $setting_value, $lasso_field_info = null) {
        global $lb_plugin;

        if(!$lasso_field_info) $lasso_field_info = $lb_plugin->lasso_field_info($project_id, $setting_id);
        $html = '<fieldset>';
        if(!!$lasso_field_info['description']) $html .= '<legend class="screen-reader-text"></legend>';
        if($lasso_field_info['tag'] == 'checkbox') {
            $html .= '<label for="'.$setting_id.'">';
            $html .= '<input type="checkbox" name="wpcf7-lasso['.$setting_id.']" id="'.$setting_id.'" value="'.$lasso_field_info['options'][0]['id'].'"';
            if($setting_value == $lasso_field_info['options'][0]['id']) $html .= ' checked="checked"';
            $html .= '>';
            $html .= $lasso_field_info['options'][0]['name'];
            $html .= '</label>';
        } else if(($lasso_field_info['tag'] == 'select') || ($lasso_field_info['tag'] == 'multi_select') || ($lasso_field_info['tag'] == 'radio')) {
            $is_multiple = ($lasso_field_info['tag'] == 'multi_select');
            $value_field = $lasso_field_info['option']['value'];
            $name_field = $lasso_field_info['option']['name'];
            $html .= '<select name="wpcf7-lasso['.$setting_id.']'.($is_multiple ? '[]' : '').'"'.($is_multiple ? ' multiple' : '').'>';
            if(!$is_multiple) {
                $html .= '<option value="0"';
                if(!$setting_value) $html .= ' selected="selected"';
                $html .= '>'.esc_html(__('Set by a form field', 'lb-plugin-strings')).'</option>';
            }
            if(!empty($lasso_field_info['options'])) {
                foreach($lasso_field_info['options'] as $options) {
                    $html .= '<option value="'.$options->$value_field.'"';
                    if($is_multiple && in_array($options->$value_field, $setting_value)) $html .= ' selected="selected"';
                    else if($setting_value == $options->$value_field) $html .= ' selected="selected"';
                    $html .= '>'.$options->$name_field.'</option>';
                }
            }
            $html .= '</select>';
        } else if($lasso_field_info['tag'] == 'input') {
            $html .= '<input type="text" name="wpcf7-lasso['.$setting_id.']" id="'.$setting_id.'" value="'.esc_attr($setting_value).'" class="regular-text code" />';
        } else if($lasso_field_info['tag'] == 'textarea') {
            $html .= '<textarea id="'.$setting_id.'" name="wpcf7-lasso['.$setting_id.']" cols="100" rows="8" class="large-text">'.$setting_value.'</textarea>';
        }
        $html .= '</fieldset>';
        return $html;
    }
    public function lasso_editor_panel($form) {
        $form_properties = $form->get_properties();
// error_log('DEBUG: load form #'.$form->id().': '.print_r($form_properties, true));
        if(!isset($form_properties['lasso'])) $form_properties['lasso'] = [];
        $count_projects = $this->lasso_auto_assign_project_id($form_properties['lasso']);
// echo 'DEBUG lasso_editor_panel: form_properties='.print_r($form_properties, true).', count_projects='.$count_projects."\n";
        if(($count_projects > 1) && !$form_properties['lasso']['project_id']) $form_properties['lasso']['project_id'] = 0;
        else {
            $form_properties['lasso'] = wp_parse_args(
                $form_properties['lasso'],
                $this->lasso_setting($form_properties['lasso']['project_id'])
            );
            if(!array_key_exists('legacy_mode', $form_properties['lasso'])) $form_properties['lasso']['legacy_mode'] = false;
            $form_properties['lasso']['skip_mail'] = $form->in_demo_mode() || $form->is_true('skip_mail');
        } 
        include(dirname(__FILE__).'/../templates/contact-form-settings.php');
    }
    public function wpcf7_save_contact_form($contact_form, $args, $context) {
        if($context == 'save') {
            $input = isset($_POST['wpcf7-lasso']) ? (array)$_POST['wpcf7-lasso'] : [];
            $input['sendSalesRepAssignmentNotification'] = !!array_key_exists('sendSalesRepAssignmentNotification', $input);
            $input['sendOptInEmail'] = !!array_key_exists('sendOptInEmail', $input);
            $input['legacy_mode'] = !!array_key_exists('legacy_mode', $input);
// error_log('DEBUG: save form #'.$contact_form->id().': input='.print_r($input, true));
            /*
            $contact_form->set_properties([
                'lasso' => $input
            ]);
            */

            $form_properties = $contact_form->get_properties();
            $form_properties['lasso'] = $input;
            $input = $contact_form->initial() || (isset($_POST['wpcf7-lasso-skip-mail']) && !!preg_match('/^(y|t|1)/i', $_POST['wpcf7-lasso-skip-mail']));
            $additional_settings = $form_properties['additional_settings'];
            if(empty($additional_settings) && $input) $additional_settings = 'skip_mail: on';
            else {
                $is_on = false;
                if(preg_match('/skip_mail\:\s*?(on|off|true|false)[\r\n]*?/i', $additional_settings, $matches)) $is_on = $matches[1] == 'on';
                if(!$input && $is_on) $additional_settings = preg_replace('/skip_mail\:\s*?(on|off|true|false)[\r\n]*?/i', '', $additional_settings);
                else if($input && !$is_on) $additional_settings .= "\n".'skip_mail: on';
            }
            $form_properties['additional_settings'] = $additional_settings;
// error_log('DEBUG: save form #'.$contact_form->id().': '.print_r($form_properties, true));
            $contact_form->set_properties($form_properties);
        }
    }
    private function current_contact_form_properties($form = null) {
        if(!$form) $form = wpcf7_get_current_contact_form();
        $form_properties = $form->get_properties();
        if(!isset($form_properties['lasso'])) $form_properties['lasso'] = [];
        $this->lasso_auto_assign_project_id($form_properties['lasso']);
        $form_properties['lasso'] = wp_parse_args(
            $form_properties['lasso'],
            $this->lasso_setting($form_properties['lasso']['project_id'])
        );
        if(!array_key_exists('legacy_mode', $form_properties['lasso'])) $form_properties['lasso']['legacy_mode'] = false;
        $form_properties['lasso']['skip_mail'] = $form->in_demo_mode() || $form->is_true('skip_mail');
        return $form_properties;
    }
    private function current_contact_form_lasso_properties($form = null) {
        $properties = $this->current_contact_form_properties($form);
        return isset($properties['lasso']) ? $properties['lasso'] : null;
    }
    public function wpcf7_math_equation_shortcode_handler($tag) {
        return $this->if_simple_captcha_active(function() use($tag) {
            $equation = $this->session_get('cf7-lasso-equation');
            if(!$equation) {
                $this->session_set('cf7-lasso-solution', $this->captcha($equation));
                $this->session_set('cf7-lasso-equation', $equation);
            }
            return '<span class="what-is">'.$equation.'</span>';
        }, function() {
            return '';
        });
    }
    public function wpcf7_math_response_shortcode_handler($tag) {
        return $this->if_simple_captcha_active(function() use($tag) {
            $tag = new WPCF7_FormTag($tag);
            $tag->name = 'cf7-lasso-it-is';
            
            $validation_error = wpcf7_get_validation_error($tag->name);
            $class = wpcf7_form_controls_class($tag->type, 'wpcf7-text');
            if($validation_error) $class .= ' wpcf7-not-valid';
            
            $atts = array();
            $atts['class'] = $tag->get_class_option($class);
            $atts['id'] = $tag->get_id_option();
            $atts['tabindex'] = $tag->get_option('tabindex', 'int', true);
            if($tag->is_required()) $atts['aria-required'] = 'true';
            $atts['aria-invalid'] = $validation_error ? 'true' : 'false';
            
            $value = (string)reset($tag->values);
            $value = $tag->get_default_option($value);
            $value = wpcf7_get_hangover($tag->name, $value);
            $atts['value'] = $value;
            $atts['type'] = 'text';
            $atts['name'] = $tag->name;
            $atts = wpcf7_format_atts($atts);
            
            return sprintf('<span class="wpcf7-form-control-wrap '.$tag->name.'"><input %1$s /></span>', $atts);
        }, function() {
            return '';
        });
    }
    public function wpcf7_hidden_shortcode_handler($tag) {
        $tag = new WPCF7_FormTag($tag);
        if(empty($tag->name)) return '';
        
        $this->form_analytics = true;
        $validation_error = wpcf7_get_validation_error($tag->name);
        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-hidden');
        if($validation_error) $class .= ' wpcf7-not-valid';
        $class .= 'hidden';
        
        $atts = array();
        $atts['class'] = $tag->get_class_option($class);
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'int', true);
        if($tag->is_required()) $atts['aria-required'] = 'true';
        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';
        
        $value = (string)reset($tag->values);
        $value = $tag->get_default_option($value);
        $value = wpcf7_get_hangover($tag->name, $value);
        $atts['value'] = $value;
        $atts['type'] = 'hidden';
        $atts['name'] = $tag->name;
        $atts = wpcf7_format_atts($atts);
        
        $html = sprintf('<input %1$s />', $atts);
        
        return $html;
    }
    public function wpcf7_add_equation_tag_generator($contact_form) {
        ?>
        <div id="cf7Lasso-tg-pane-equation">
            <form action="">
                <div class="control-box">
                    <fieldset>
                        <legend>Generate a math equation; needs to be paired with a solution field.</legend>
        
                    </fieldset>
                </div>
        
                <div class="insert-box">
                    <input type="text" name="equation" class="tag code" readonly="readonly" onfocus="this.select()">
        
                    <div class="submitbox">
                        <input type="button" class="button button-primary insert-tag" value="Insert Tag">
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
    public function wpcf7_add_solution_tag_generator($contact_form) {
        ?>
        <div id="cf7Lasso-tg-pane-solution">
            <form action="">
                <div class="control-box">
                    <fieldset>
                        <legend>Generate a math response field; needs to be paired with a equation field.</legend>
                        <input type="hidden" name="name" value="cf7-lasso-it-is" class="tg-name oneline" id="tag-generator-panel-solution-name">
                    </fieldset>
                </div>
        
                <div class="insert-box">
                    <input type="text" name="solution" class="tag code" readonly="readonly" onfocus="this.select()">
        
        
                    <div class="submitbox">
                        <input type="button" class="button button-primary insert-tag" value="Insert Tag">
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
    public function wpcf7_add_tag_generator($contact_form) {
        ?>
        <div id="cf7Lasso-tg-pane-hidden">
            <form action="">
                <div class="control-box">
                    <fieldset>
                        <legend>Generate a form-tag for a hidden field.</legend>
        
                        <table class="form-table">
                            <tbody>
                                <tr>
                                    <th scope="row"><?php echo esc_html(__('Field Type', 'contact-form-7' )); ?></th>
                                    <td>
                                        <fieldset>
                                            <legend class="screen-reader-text"><?php echo esc_html(__('Field Type', 'contact-form-7' )); ?></legend>
                                            <label><input type="checkbox" name="required"> <?php echo esc_html(__('Required field', 'contact-form-7' )); ?></label>
                                        </fieldset>
                                    </td>
                                </tr>
        
                                <tr>
                                    <th scope="row"><label for="tag-generator-panel-hidden-name">Name</label></th>
                                    <td><input type="text" name="name" class="tg-name oneline" id="tag-generator-panel-hidden-name"></td>
                                </tr>
        
                                <tr>
                                    <th scope="row"><label for="tag-generator-panel-hidden-values">Default value</label></th>
                                    <td>
                                        <input type="text" name="values" class="oneline" id="tag-generator-panel-hidden-values"><br>
                                    </td>
                                </tr>
        
        
                                <tr>
                                    <th scope="row"><label for="tag-generator-panel-hidden-id">Id attribute</label></th>
                                    <td><input type="text" name="id" class="idvalue oneline option" id="tag-generator-panel-hidden-id"></td>
                                </tr>
        
                            </tbody>
                        </table>
                    </fieldset>
                </div>
        
                <div class="insert-box">
                    <input type="text" name="hidden" class="tag code" readonly="readonly" onfocus="this.select()">
        
                    <div class="submitbox">
                        <input type="button" class="button button-primary insert-tag" value="Insert Tag">
                    </div>
        
                    <br class="clear">
        
                    <p class="description mail-tag"><label for="tag-generator-panel-hidden-mailtag">To use the value input through this field in a mail field, you need to insert the corresponding mail-tag (<strong><span class="mail-tag"></span></strong>) into the field on the Mail tab.<input type="text" class="mail-tag code hidden" readonly="readonly" id="tag-generator-panel-hidden-mailtag"></label></p>
                </div>
            </form>
        </div>
        <?php
    }
    public function wpcf7_form_tag($scanned_tag, $replace) {
        $lasso_form_properties = $this->current_contact_form_lasso_properties();
        if(!isset($lasso_form_properties)) $lasso_form_properties = [];
        $this->lasso_auto_assign_project_id($lasso_form_properties);
// echo 'DEBUG: replace='.intVal(!!$replace).', queued? '.intVal(!!wp_script_is('lb-plugin-frontend-js', 'enqueued'))."\n";
        if($replace && !wp_script_is('lb-plugin-frontend-js', 'enqueued')) {
// echo 'DEBUG: form_properties='.print_r($this->current_contact_form_properties(), true)."\n";
            if(!empty($lasso_form_properties) && !empty($lasso_form_properties)) {
                wp_enqueue_script('lb-plugin-frontend-js');

// echo 'DEBUG: lasso_form_properties='.print_r($lasso_form_properties, true)."\n";
                if($lasso_form_properties['project_id']) {
                    $lasso_form_fields = $this->lasso_form_fields($lasso_form_properties['project_id']);
                    $javascript = [];
                    foreach($lasso_form_fields as $lasso_form_field) {
                        $lasso_field_info = $this->lasso_field_info($lasso_form_properties['project_id'], $lasso_form_field);
                        $javascript[$lasso_form_field] = $lasso_field_info;
                    }
                    wp_localize_script('lb-plugin-frontend-js', 'lasso_form_fields', $javascript);
                }
            }
// exit();
        }
        if(!preg_match('/^lasso/i', $scanned_tag['type'])) {
            if($this->lasso_harvesting_proxy) $this->lasso_proxy = $scanned_tag;
            return $scanned_tag;
        }
        $shortcode = '[';
        $type = 'text';
        $id = $scanned_tag['name'];
        $name_suffix = '';
        $choices_count = count($scanned_tag['raw_values']);
        $lasso_field_info = $this->lasso_field_info($lasso_form_properties['project_id'], preg_replace('/^Q/', '', $scanned_tag['raw_name']));
        $default_value = null;
        $display_as = $lasso_field_info['default_display_as'];
        $address_type = null;
        if(!empty($scanned_tag['options'])) {
            foreach($scanned_tag['options'] as $option) {
                if(preg_match('/^address\-type\:(.+)/', $option, $matches)) $address_type = $matches[1];
                if(preg_match('/^default\-value\:([^\s]+)/', $option, $matches)) $default_value = preg_replace('/\+/', ' ', $matches[1]);
                if(preg_match('/^display-as\:(.+)/', $option, $matches)) $display_as = $matches[1];
            }
        }
        switch($lasso_field_info['tag']) {
            case 'date':
                $type = 'date';
            break;
            case 'checkbox':
                $type = 'checkbox';
                $name_suffix .= ' use_label_element';
            break;
            case 'radio':
                $type = 'radio';
                $name_suffix .= ' use_label_element';
            break;
            case 'textarea':
                $type = 'textarea';
            break;
            case 'multi_select':
                if(!$display_as && ($choices_count <= 3)) {
                    $type = 'checkbox';
                    $name_suffix .= ' use_label_element';
                } else {
                    $type = $display_as ? $display_as : 'select';
                    $name_suffix .=' multiple';
                }
            break;
            case 'select':
                if(!$display_as && ($choices_count <= 3)) {
                    $type = 'radio';
                    $name_suffix .= ' use_label_element';
                } else {
                    $type = $display_as ? $display_as : 'select';
                }
            break;
        }
        if($display_as == 'hidden') $type = 'hidden';
        if($type == 'radio') $name_suffix .= ' default:1';
        $shortcode .= $type;
        if(preg_match('/^lasso\*/i', $scanned_tag['type'])) $shortcode .= '*';
        $shortcode .= ' '.$scanned_tag['raw_name'].' class:lasso-value'.$name_suffix;
        if(!empty($scanned_tag['options']) && in_array('placeholder', $scanned_tag['options'])) $shortcode .= ' placeholder';
        $options = '';
        if(!empty($scanned_tag['raw_values'])) {
            foreach($scanned_tag['raw_values'] as $index => $option) {
                if(
                    is_string($default_value) &&
                    (
                        (strtolower(preg_replace('/^(?:[^\|]+\|)(.+?)$/', '$1', $option)) == strtolower($default_value)) ||
                        (strtolower($option) == strtolower($default_value))
                    )
                ) $default_value = $index + 1;
                $options .= ' "'.$option.'"';
            }
        }
        if(($default_value !== null) && ($default_value !== '')) {
            if(is_string($default_value)) $shortcode .= $options.' "'.urldecode($default_value).'"';
            else $shortcode .= ' default:'.$default_value.' '.$options;
        } else $shortcode .= $options;
        $shortcode .= ']';
// echo '[JEAN[shortcode 2='.$shortcode.']]';

        $form_tags_manager = clone WPCF7_FormTagsManager::get_instance(); // to avoid our scanned tags to be duplicated
        $this->lasso_harvesting_proxy = true;
        $scanned_tag = $form_tags_manager->scan($shortcode, $replace);
        if($this->lasso_proxy) $scanned_tag = $this->lasso_proxy;
        if($lasso_field_info['tag'] == 'full-address') {
            $state_provinces = [];
            foreach($lasso_field_info['options'] as $option) $state_provinces[] = $option['name'].'|'.$option['id'];

            $this->html_snippets[$id] = $form_tags_manager->scan('[text address class:lasso-value class:lasso-address]', true);
            if($address_type) {
                $address_types = [];
                $address_type_field_info = $this->lasso_field_info($lasso_form_properties['project_id'], 'addressType');
                foreach($address_type_field_info['options'] as $option) $address_types[] = $option['name'].'|'.$option['id'];
                $this->html_snippets[$id] .= $form_tags_manager->scan('[hidden addressType class:lasso-value class:lasso-address "'.$address_type.'"]', true);
            }
            $this->html_snippets[$id] .= $form_tags_manager->scan('[text city class:lasso-value class:lasso-address]', true);
            $this->html_snippets[$id] .= $form_tags_manager->scan('[select state class:lasso-value class:lasso-address "'.implode('" "', $state_provinces).'"]', true);
            $this->html_snippets[$id] .= $form_tags_manager->scan('[text zipCode class:lasso-value class:lasso-address]', true);
            $countries = [
                __('Canada', 'lb-plugin-strings'),
                __('United States', 'lb-plugin-strings'),
                __('Other', 'lb-plugin-strings')
            ];
            if($default_value) {
                foreach($countries as $index => $option) {
                    if(
                        is_string($default_value) &&
                        (
                            (strtolower(preg_replace('/^(?:[^\|]+\|)(.+?)$/', '$1', $option)) == strtolower($default_value)) ||
                            (strtolower($option) == strtolower($default_value))
                        )
                    ) $default_value = $index + 1;
                }
            }
            $this->html_snippets[$id] .= $form_tags_manager->scan('[select country'.($default_value ? ' default:'.$default_value : '').' class:lasso-value class:lasso-address class:lasso-group-owner "'.implode('" "', $countries).'"]', true);
        } else $this->html_snippets[$id] = $form_tags_manager->scan($shortcode, true);
        $this->lasso_proxy = null;
        $this->lasso_harvesting_proxy = false;
        /* LAST RESORT: if CF7 decides to change method names, our plugin will break!
        $func = 'wpcf7_'.$type.'_form_tag_handler';
        if(function_exists($func)) $this->html_snippets[$id] = call_user_func($func, new WPCF7_FormTag($scanned_tag));
        */
/*
if($replace && ($lasso_field_info['tag'] == 'full-address')) {
    echo 'DEBUG: shortcode='.$shortcode.', scanned_tag='.print_r($scanned_tag, true).', snippet='.print_r($this->html_snippets[$id], true);
    exit();
}
*/

        return $scanned_tag;
    }
    public function lasso_form_field($tag) {
        $html = '';
        if(!$this->form_output) {
            $this->form_output = true;
            $html .= '<input type="hidden" name="guid" value="" />';
        }
        if(array_key_exists($tag->name, $this->html_snippets)) $html .= $this->html_snippets[$tag->name];
        return $html;
    }
    public function lasso_field_editor($contact_form, $args = '') {
        $form_properties = $contact_form->get_properties();
        if(!isset($form_properties['lasso'])) $form_properties['lasso'] = [];
        $this->lasso_auto_assign_project_id($form_properties['lasso']);
        $project_id = $form_properties['lasso']['project_id'];
        if($project_id) $lasso_form_fields = $this->lasso_form_fields($project_id);
        else $lasso_form_fields = null;
        include(dirname(__FILE__).'/../templates/contact-form-field-settings.php');
    }
    public function wpcf7_mail_sent($contact_form) {
        $submission = WPCF7_Submission::get_instance();
        if($submission) {
            $posted_data = $submission->get_posted_data();
            if(!empty($posted_data)) {
                $form_properties = $contact_form->get_properties();
                $properties = wp_parse_args(
                    $form_properties['lasso'],
                    $this->lasso_setting($form_properties['lasso']['project_id'])
                );
                if((array_key_exists('legacy_mode', $properties) && $properties['legacy_mode']) || !!$contact_form->additional_setting('Lasso')) $this->wpcf7_legacy_mail_sent($contact_form, $submission, $posted_data);
                else {
                    $posted_data = array_merge($properties, $posted_data);
                    $this->lasso_auto_assign_project_id($properties);
                    $response = $this->post_registrant_data($properties['project_id'], $posted_data);
                    if(isset($response->errorCode)) {
                        $submission->set_status('validation_failed');
                        $message = @json_decode($response->errorMessage);
                        if($message) $message = $message->message;
                        else $message = preg_replace('/^\{message\=(.+?)\}$/', '$1', $response->errorMessage);
                        $submission->set_response($message ? $message : $response->errorMessage);
                    }
                }
            }
        }
    }

    private function wpcf7_legacy_mail_sent($contact_form, $submission, $submission_data) {
        $lasso = $contact_form->additional_setting('Lasso');
        if(!empty($lasso)) {
            $properties = @json_decode($lasso[0], true);
            if($properties) $submission_data = array_merge($properties, $submission_data);
            $lasso_fields = array(
                'FirstName',
                'LastName',
                'NameTitle', // Mr, Mrs, ...
                'Address',
                'City',
                'Province',
                'PostalCode',
                'Country',
                'Company',
                'JobTitle',
                'SIN',
                'Phones-Home',
                'Phones-Cell',
                'Phones-Work',
                'Phones-WorkExt',
                'Phones-Fax',
                'Phones-Pager',
                'Emails-Primary',
                'Emails-Secondary',
                'Emails-Tertiary',
                'Comments',
                'Gender',
                'ContactPreference',
                'SignupThankyouLink',
                'SignupEmailLink',
                'SignupEmailSubject',
                'guid',
                'domainAccountId',
                'RatingID',
                'followUpProcessId',

                // obsolete - use NameTitle instead
                'Mr',
                'Mrs',
                'Miss',
                'Ms',
                'Dr',
                'Sir',
                'Capt',
                'Prof',
                'Rev',
                'Mstr'
            );
            
            /*
            To indicate a Lasso field should be sent as an array, end it's CF7 name with "-", i.e. "Questions-1234-"
            */
            $posted_data = [];
            foreach($submission_data as $key => $value) {
                if(!in_array($key, $lasso_fields) && !preg_match('/^Questions\-/', $key)) continue;

                do {
                    $key = preg_replace('/\-([^\-]*?)(\-|$)/', '[$1]$2', $key);
                } while(preg_match('/\-([^\-]*?)(\-|$)/', $key));

                if(preg_match('/^(mrs?|miss|ms|dr)$/i', $key)) $key = 'NameTitle';

                $posted_data[$key] = $value;
            }

            foreach($posted_data as $key => $value) {
                if(is_array($value)) {
                    if(preg_match('/\[\]$/', $key)) { // Both CF7 and Lasso fields are arrays
                        unset($posted_data[$key]);
                        $key = preg_replace('/\[\]$/', '', $key);
                        $posted_data[$key] = $value;
                    } else { // CF7 is an array && Lasso field is NOT an array
                        $new_value = '';
                        if(!empty($value)) {
                            foreach($value as $field_id => $mappings) {
                                if(preg_match('/^0$/', $field_id)) $new_value = $mappings;
                                else {
                                    $field_id = preg_replace('/\-([^\-]+)(\-|$)/', '[$1]$2', $field_id);
                                    if(isset($posted_data[$field_id]) && isset($mappings[$posted_data[$field_id]])) $new_value .= $mappings[$posted_data[$field_id]];
                                }
                            }
                        }
                        $posted_data[$key] = $new_value;
                    }
                }
            }

            $api_data = [
                'websiteTracking' => ['guid'],
                'person' => ['nameTitle' => 'NameTitle', 'firstName' => 'FirstName', 'lastName' => 'LastName', 'company' => 'Company', 'contactPreference' => 'ContactPreference', 'gender' => 'Gender', 'ssnSin'],
                'rating' => ['rating' => 'RatingID'],
                'sourceType' => ['sourceType' => 'SourceTypeID'],
                'secondarySourceType' => ['secondarySourceType' => 'SecondarySourceTypeID'],
                'followUpProcess' => ['followUpProcessId'],
                'questions' => [],
                // 'history' => [],
                'notes' => ['note*' => 'Comments']
            ];
            $form_properties = $contact_form->get_properties();
            if(!isset($form_properties['lasso'])) $form_properties['lasso'] = [];
            $this->lasso_auto_assign_project_id($form_properties['lasso']);
        
            $this->legacy_mode = true;
            $this->post_registrant_data($form_properties['lasso']['project_id'], $posted_data, $api_data);
            $this->legacy_mode = false;
        }
    }
}
?>
