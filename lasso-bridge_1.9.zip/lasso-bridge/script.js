(function($) {
    if(!$) return;
    $(function() { 
        // *** Common
        var get_field_info = function(field) {
            if(!!window.lasso_form_fields && !!window.lasso_form_fields[field]) return window.lasso_form_fields[field]
            return {}
        };

        // *** ContactForm 7
        var cancel_adding = function(button) {
            var table = button.closest("table");
            table.removeClass("active");
            table.find("input").val("");
        }
        $("#lasso-add-api-key").on("click", function(event) {
            event.preventDefault();
            var button = $(this);
            var table = button.closest("table");
            if(table.is(".active")) {
                $(".lasso-settings-new-api-key form.lasso-settings").submit();
                cancel_adding(button);
            } else {
                table.addClass("active");
                $(".lasso-settings-new-api-key input").focus();
            }
        });
        $(".lasso-settings-new-api-key .button-cancel").on("click", function(event) {
            event.preventDefault();
            cancel_adding($(this));
        });
        $(".lasso-postbox .lasso-postbox-header").on("click", function(event) {
            event.preventDefault();
            var header = $(this);
            var box = header.closest(".lasso-postbox");
            box.toggleClass("active");
        });

        var box = $(".lasso-postbox").first();  
        if(document.location && document.location.search) {
            var matches = document.location.search.match(/(?:\?|&)focus\=([^&|$]+)/);
            if(matches) box = $(".lasso-postbox#lasso-project-" + matches[1])
        }
        box.find(".lasso-postbox-header").click();

        var regenerate_wcf7_field = function(container) {
            var options = [];
            container.find(".lasso-option").each(function() {
                var option = $(this)
                var label = option.find("input[type='text']");
                var value = option.find("input[type='hidden']");
                options.push(label.val() + "|" + value.val());
            });
            var wcf7_field = $(".lasso-content textarea.values");
            wcf7_field.val(options.join("\n")).change();
        };
        var reset_options = function(field_type, add, reroot) {
            if(!field_type) field_type = $(".lasso-field-type").val();
            var field_info = get_field_info(field_type);
            var standardized_tag = field_info.tag;
            if((standardized_tag === "checkbox") && (field_info.options.length > 1)) standardized_tag = "checkboxes";
            var settings = $(".lasso-setting-" + standardized_tag);

            var options = settings.find(".lasso-options");
            var current_options = reroot ? null : options.data("current-options");
            if(!current_options) {
                current_options = field_info.options.map(function(item) { return item; });
                options.data("current-options", current_options);
            }
            var is_options_field = ((field_info.tag === 'select') || (field_info.tag === 'multi_select') || (field_info.tag === 'checkbox') || (field_info.tag === 'checkboxes') || (field_info.tag === 'radio'));
            var template = options.data("_template");

            options.find(".lasso-option").remove();
            if(is_options_field) {
                var value_field = field_info.option.value;
                var name_field = field_info.option.name;
                if(add) {
                    var new_option = {}
                    new_option[value_field] = "";
                    new_option[name_field] = "";
                    current_options.push(new_option);
                    options.data("current-options", current_options);
                }
                for(var loop = 0; loop < current_options.length; loop++) {
                    var option = current_options[loop];
                    var node = template.clone(true);
                    node.find("input[type='hidden']").val(option[value_field]);
                    node.find("input[type='text']").val(option[name_field]);
                    node.find("span.raw-value").text(option[value_field]);
                    node.find("span.original-value").text(" (" + option[name_field] + ")");
                    options.append(node);
                }
            }

            settings.find("select.lasso-address-type").each(function() {
                var address_type_setting = $(this);
                var address_type_field_info = get_field_info("addressType");
                if(!!address_type_field_info.default_value) address_type_setting.val(address_type_field_info.default_value).change();
            });
            settings.find(".lasso-display-as-proxy").each(function() {
                var proxy_setting = $(this);
                if(proxy_setting.is("input[type=checkbox]")) proxy_setting.prop("checked", !!field_info.default_display_as).change();
                else if(!!field_info.default_display_as) proxy_setting.val(field_info.default_display_as).change();
                
                if(field_type.match(/^(address|email|phone)Type$/i)) {
                    $("fieldset.lasso input[name='default-value']").val(is_options_field ? field_info.options[0][field_info.option.value] : "");
                }
            });

            regenerate_wcf7_field(settings);

            if(field_type.match(/^(address|email|phone)Type$/i)) {
                settings.not(".lasso-display-as-proxy-row").show();
                settings.filter(".lasso-display-as-proxy-row").hide();
            } else settings.show();
        };
        $(".lasso-field-type").on("change", function() {
            var menu = $(this);
            var field_type = menu.val();
            if(!field_type) return;
            menu.parent().find('input[name="name"]').val(!!field_type.match(/^\d+$/) ? "Q" + field_type : field_type).change();
            $(".lasso-setting").hide();
           
            $(".lasso-setting :input:not([type=checkbox]), .oneline.option").each(function() {
                var node = $(this);
                var value = ""
                if(node.is("select.lasso-address-type")) value = node.children().first().val();
                node.val(value);
            });

            reset_options(field_type, false, true);
       }).change();
       $(".lasso-display-as-proxy").each(function() {
           var container = $(this);
           container.on("change", function() {
                var value = container.val();
                if(container.is("[type=checkbox]:not(:checked)")) value = "";
                container.closest("td").find("input[name='display-as']").val(value).change();
           }).change();
       });
       $("select.lasso-address-type").each(function() {
           var container = $(this);
           container.on("change", function() {
                var value = container.val();
                container.closest("td").find("input[name='address-type']").val(value);
                regenerate_wcf7_field($(".lasso-options"));
            }).change();
       });
       $(".lasso-options").each(function() {
            var container = $(this);
            if(!container.data("_template")) {
                var template = container.find(".lasso-option").detach();
                if(template) container.data("_template", template);
            }

            container.on("change", ".lasso-option input[type='text']", function() {
               regenerate_wcf7_field(container);
               var field = $(this);
               var node = field.closest(".lasso-option");
               var new_value = field.val();
               var original_value_field = node.find("span.original-value");
               var original_value = original_value_field.text();
                var field_type = $(".lasso-field-type").val();
                var field_info = get_field_info(field_type);
                var index = node.index() - 1;
                if((index >= 0) && !!field_info.options && (!field_info.options[index].id || field_info.options[index].match(/^\d+$/))) {
                    field_info.options[index].id = new_value;
                    node.find("input[type='hidden']").val(new_value);
                    original_value = new_value;
                    original_value_field.text(new_value);
                }
                original_value_field.toggle(original_value.toLowerCase() !== new_value.toLowerCase());
                regenerate_wcf7_field(container);
            }).change();
            container.on("click", ".lasso-option .button.lasso-option-remove", function() {
                var node = $(this).closest(".lasso-option");
                var options = node.closest(".lasso-options");
                var current_options = options.data("current-options");
                var index = node.index() - 1;
                if((index >= 0) && (index < current_options.length)) {
                    current_options.splice(index, 1);
                    options.data("current-options", current_options);
                }
                node.remove();
                regenerate_wcf7_field(container);
            });
        });
        $(".lasso-setting .button.lasso-option-add").on("click", function() {
            reset_options(null, true);
        });
        $("#tag-generator-panel-lasso .insert-tag").on("click", function() {
            reset_options($(".lasso-field-type").val(), false, true);
        });
        var toggle_legacy_mode = function() {
            var legacy = $("#wpcf7-lasso-legacy_mode").is(':checked');
            $(".lasso-form-settings tr").each(function() {
                var row = $(this);
                if(!row.find("#wpcf7-lasso-legacy_mode").length) row.toggle(!legacy);
            });
            $("#tag-generator-list a[href*='tag-generator-panel-lasso']").toggle(!legacy);
        };
        $("[name='default-value']").on("change", function() {
            var field = $(this);
            var value = field.val();
            if(value && !value.match(/\s/)) return;
            field.val(value.replace(/\s/g, "+")).change();
        });
        $("#go-to-lasso-settings").on("click", function(event) {
            event.preventDefault();
            var link = $(this);
            $(link.attr("href")).children("a").click();
            $("#TB_closeWindowButton").click();
        });
        $("#wpcf7-lasso-legacy_mode").on("click", function() {
            toggle_legacy_mode();
        });
        toggle_legacy_mode();

        var wpcf7_tab_navigate = function(tab_id) {
            if(tab_id && !tab_id.match(/\-tab$/)) tab_id += '-tab';
            $(tab_id).find("a").click();
        };
        if(document.location.hash) {
            setTimeout(function() {
                wpcf7_tab_navigate(document.location.hash);
            }, 500);
        }
        $("#remove-api-key").on("click", function(event) {
            event.preventDefault();
            var form = $(this).closest("form");
            form.find("#_noop").attr("name", "_gform_setting_api_key");
            form.find("#gform-settings-save").click();
        })

        // *** Gravity Forms
        if(!!window.gform) {
            var type_mappings = { // <GF field type>: [<lasso field type(s)]
                "text": ["input"],
                "number": ["input"],
                "select": ["select", "radio"],
                "checkbox": ["multiselect", "checkbox"],
                "radio": ["select", "radio"],
                "name": "fullName",
                "date": ["date"],
                // "phone": "phones", // *****
                "address": "addressBlock",
                "name": "nameBlock",
                // "email": "emails" // *****
            };
            $(document).on('gform_load_field_settings', function(event, field, form) {    
                $(".prepopulate_field_setting.field_setting").show();
                var is_lasso_field = !!field.type.match(/^lb_/);
                $(".duplicate_setting").closest("li").toggle(!is_lasso_field);
                if(is_lasso_field) {
                    var menu = $("li.option_field_type_setting #option_field_type").first();
                    if(menu.length) {
                        var gf_type = menu.val();
        
                        menu.children().each(function() {
                            var option = $(this);
                            if(!!type_mappings[gf_type]) option.toggle(type_mappings[gf_type].indexOf(option.val()) >= 0);
                        });
                        if(field.type === "lb_question") {
                            var sub_type = $("li.option_field_type_setting.field_setting");
                            if(field.inputType.match(/^(select|radio|checkbox)$/)) sub_type.show();
                            else sub_type.hide();
                        } // else menu.append('<option value="address">Address</option>');
                        // menu.append('<option value="hidden">Hidden Value</option>');
                    }
                    if(field.type === "lb_name"){
                        if((typeof field["nameFormat"] == 'undefined') || (field["nameFormat"] != "advanced")) field = MaybeUpgradeNameField(field);
                        else SetUpAdvancedNameField();
                
                        if(field["nameFormat"] == "simple"){
                            $(".default_value_setting").show();
                            $(".size_setting").show();
                            $('#field_name_fields_container').html('').hide();
                            $('.sub_label_placement_setting').hide();
                            $('.name_prefix_choices_setting').hide();
                            $('.name_format_setting').hide();
                            $('.name_setting').hide();
                            $('.default_input_values_setting').hide();
                            $('.default_value_setting').show();
                        } else if(field["nameFormat"] == "extended") {
                            $('.name_format_setting').show();
                            $('.name_prefix_choices_setting').hide();
                            $('.name_setting').hide();
                            $('.default_input_values_setting').hide();
                            $('.input_placeholders_setting').hide();
                        }
                        $(".name_setting").find("tr[data-input_id$='\.4'], tr[data-input_id$='\.8']").hide()
                        $(".input_placeholders_setting").find("tr.input_placeholder_row[data-input_id$='\.4'], tr.input_placeholder_row[data-input_id$='\.8']").hide()
                    } else if(field.type === "lb_address_block") {
                        var _cache = window.SetAddressType;
                        field.type = "address";
                        window.SetAddressType = function(isInit) {
                            _cache.call(window, isInit);
                            field.type = "lb_address_block";
                            window.SetAddressType = _cache;
                        };
                        window.SetAddressType(true);
                        $(".address_setting").find("tr[data-input_id$='\.2']").hide()
                        $(".address_setting").find("tr[data-input_id$='\.7']").hide()
                    } else if(field.type === "lb_question") {
                        $(".prepopulate_field_setting.field_setting").hide();
                        var question_menu = $("#lasso_question").on("change", function() {
                            var label = $(this).val();
                            SetInputName(label);
                            field.label = get_field_info(field.inputName).label || label;
                        });
                        if(field.inputName) question_menu.val(field.inputName);
                    }
                }
            }).on('gform_load_field_choices', function(event, field) {
                var is_lasso_field = !!field.type.match(/^lb_/);
                $("#field_choices .field-choice-input.field-choice-value").prop("disabled", is_lasso_field);
                // $("#field_choices button.field-choice-button.field-choice-button--insert").toggle(!is_lasso_field);
            }).on("gform_field_added", function(event, form, field) {
                if(field["type"] === "lb_question") {
                    window.field = $('#field_' + field.id);
                    window.field.addClass('field_selected');
                    window.StartChangeLassoQuestionType($("#lasso_question").val(), field)
                }
            });
            window.StartChangeLassoQuestionType = function(question_id, field) {
                var field_info = get_field_info(question_id);
                if(field_info) {
                    var type = field_info.tag;
                    if(type === 'input') type = 'text';
                    else if(type === 'multi_select') type = 'multiselect';
                    if(!field) field = GetSelectedField();
                    field['inputName'] = question_id;
                    if(field) {
                        var is_options_field = ((field_info.tag === 'select') || (field_info.tag === 'multi_select') || (field_info.tag === 'checkbox') || (field_info.tag === 'checkboxes') || (field_info.tag === 'radio'));
                        if(is_options_field) {
                            var _cache = window["SetDefaultValues_" + type];
                            window["SetDefaultValues_" + type] = function(field) {
                                var value_field = field_info.option.value;
                                var name_field = field_info.option.name;
                                field.choices = [];
                                for(var loop = 0; loop < field_info.options.length; loop++) {
                                    var option = field_info.options[loop];
                                    field.choices.push(new Choice(option[name_field], option[value_field]));
                                }
                                if(field.inputs) field.inputs = null;
                                if(_cache) field = _cache.call(window, field);
                                window["SetDefaultValues_" + type] = _cache;
                                return field;
                            };
                        }
                        StartChangeInputType(type, field);
                    }
                }
            }
            gform.addFilter('gform_pre_form_editor_save', function(form) {
                for(index in form.fields) {
                    var field = form.fields[index];
                    if(field.choices) {
                        for(choice_index in field.choices) {
                            var choice = field.choices[choice_index];
                            if(!choice.value) choice.value = choice.text;
                        }
                    }
                }
                return form;
            });
            var confirm_settings_delete = function(event) {
                event.preventDefault();
                var button = $(this);
                var project_id = button.data("project-id")
                var project_name = button.data("project-name")
                if(confirm("WARNING: You are about to delete the project \"" + project_name + "\". \"Cancel\" to stop, \"OK\" to delete.")) {
                    $('#action_argument').val(project_id);
                    $('#action').val("delete");
                    button.closest("form")[0].submit();
                }
            };
            $("#gform_setting_lasso-projects .submitdelete").on("click", confirm_settings_delete).on("keypress", confirm_settings_delete);

            var init_form_settings = function() {
                if(!window.form || !window.form.id) setTimeout(init_form_settings, 100);
                else {
                    if(window.lasso_menu_page_url) {
                        var lasso_buttons_panel = $("#add_lasso-gf-buttons");
                        if(!lasso_buttons_panel.find("ul").children().length) {
                            lasso_buttons_panel.find(".gf-field-group__no-results").html("You need to <a href='" + window.lasso_menu_page_url.replace(/\{id\}/, form.id) + "'>define a Lasso feed</a> before you can add Lasso fields to your form.").show();
                        }    
                    }
                }
            };
            init_form_settings();
        }
        var project_id_field = $("#project_id");
        if(project_id_field.length) {
            var button = $("#lasso-gf-disconnect");
            if(!button.length) {
                button = $('<button type="button" id="lasso-gf-disconnect" name="lasso-gf-disconnect" value="1" class="button">Unlink this form from Lasso</button>');
                project_id_field.closest(".gform-settings-field__hidden").after($('<div class="gform-settings-field"><span class="gform-settings-description" id="description-feedName">If you unlink the form, any <em>future</em> form submission will <em>not</em> be sent to Lasso.</span></div>').prepend(button));
            }
            button.on("click", function() {
                project_id_field.val(0);
                $("#gform-settings-save, input[type=submit]").click();
            });
        }
    });
})(jQuery);
