<?php
if(!class_exists('GFForms')) die();

class LB_GF_Nametitle_Field extends LB_GF_Select_Field {
    public $type = 'lb_nameTitle';
    public $inputType = 'select';
    public $inputName = 'nameTitle';

    public function get_form_editor_field_title() {
        return esc_attr__('Title', 'lb-plugin-strings');
    }
}
GF_Fields::register(new LB_GF_Nametitle_Field());
