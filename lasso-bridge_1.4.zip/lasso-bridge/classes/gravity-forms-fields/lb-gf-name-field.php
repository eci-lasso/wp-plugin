<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoGravityFormField.php');

class LB_GF_Name_Field extends GF_Field_Name {
    use LassoGravityFormField;

    public $type = 'lb_name';
    public $inputName = 'nameBlock';
    public $inputType = 'name';

    private function name_title_choices() {
        // $form = $this->get_current_form();
		$form_properties = GFFormsModel::get_form_meta($this->formId);
		$this->lasso_auto_assign_project_id($form_properties);
        $lasso_field_info = $this->lasso_field_info($this->formId, 'nameTitle');
        $choices = [];
        foreach($lasso_field_info['options'] as $option) {
            $choices[] = [
                'value' => $option['id'],
                'text' => $option['name']
            ];
        }
        return $choices;
    }
	/*
    public function sanitize_settings_choices( $choices = null ) {
        $choices = parent::sanitize_settings_choices($choices);
        if(!empty($choices)) $choices = $this->name_title_choices();
		return $choices;
	}
    */
    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted name block to send to Lasso', 'lb-plugin-strings');
    }
    public function get_form_editor_field_title() {
        return esc_attr__('Full Name', 'lb-plugin-strings');
    }
    protected function form_editor_inline_script_content($lasso_field_info, &$function_lines, $project_id) {
        $function_lines[] = 'field.nameFormat = "advanced";';
        $function_lines[] = 'field.inputs = GetAdvancedNameFieldInputs(field, true, true, true);';
        $function_lines[] = 'field.inputs[0].choices = '.json_encode($this->name_title_choices()).';';
    }
	public function get_value_export($entry, $input_id='', $use_text=false, $is_csv=false) {
        if($is_csv) return parent::get_value_export($entry, $input_id, $use_text, $is_csv);

		if(empty($input_id)) $input_id = $this->id;
		if(absint($input_id) == $input_id) {
            return [
                'nameTitle' => str_replace('  ', ' ', trim(rgar($entry, $input_id.'.2'))),
                'firstName' => str_replace('  ', ' ', trim(rgar($entry, $input_id.'.3'))),
                'lastName' => str_replace('  ', ' ', trim(rgar($entry, $input_id.'.6'))),
            ];
		}
        
        return rgar($entry, $input_id);
	}
}
GF_Fields::register(new LB_GF_Name_Field());
