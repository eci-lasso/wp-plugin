<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoGravityFormField.php');

class LB_GF_Text_Field extends GF_Field_Text {
    use LassoGravityFormField;

    public $type = 'lb_text';
    // $this->inputName

    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted text field to send to Lasso', 'lb-plugin-strings');
    }
}
