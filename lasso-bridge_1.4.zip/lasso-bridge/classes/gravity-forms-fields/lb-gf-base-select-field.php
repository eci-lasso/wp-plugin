<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoGravityFormField.php');

class LB_GF_Select_Field extends GF_Field_Select { // ****** OR radio buttons
    use LassoGravityFormField;

    public $type = 'lb_select';

    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted drop-down menu to send to Lasso', 'lb-plugin-strings');
    }
	public function get_form_editor_field_settings() {
		return array(
			'option_field_type_setting',
			'conditional_logic_field_setting',
			'error_message_setting',
			'enable_enhanced_ui_setting',
			'label_setting',
			'label_placement_setting',
			'admin_label_setting',
			'size_setting',
			'choices_setting',
			'rules_setting',
			'placeholder_setting',
			'default_value_setting',
			'visibility_setting',
			'duplicate_setting',
			'description_setting',
			'css_class_setting',
			'autocomplete_setting',
		);
	}
    protected function form_editor_inline_script_content($lasso_field_info, &$function_lines, $project_id) {
        $choices = [];
        $value_field = $lasso_field_info['option']['value'];
        $name_field = $lasso_field_info['option']['name'];
        foreach($lasso_field_info['options'] as $option) {
            if(is_array($option)) $option = @json_decode(@json_encode($option));
            $choices[] = 'new Choice("'.$option->$name_field.'", "'.$option->$value_field.'")';
        }
// echo '[JEAN form_editor_inline_script_content[choices='.print_r($choices, true).']]';

        $function_lines[] = 'field.choices = ['.implode(', ', $choices).'];';
        $function_lines[] = 'field.enableChoiceValue = true;';
    }
}
