<?php
if(!class_exists('GFForms')) die();

class LB_GF_Email_Field extends GF_Field_Email {
    use LassoGravityFormField;

    public $type = 'lb_email';
    public $inputType = 'email';
    public $inputName = 'email';

    public function get_form_editor_field_title() {
        return esc_attr__('Email', 'lb-plugin-strings');
    }
    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted email field to send to Lasso', 'lb-plugin-strings');
    }
}
GF_Fields::register(new LB_GF_Email_Field());
