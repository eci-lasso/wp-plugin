<li class="lasso_question_setting field_setting">
    <label for="lasso_question" class="section_label">
        <?php esc_html_e('Question', 'lb-plugin-strings'); ?>
        <?php gform_tooltip('form_field_question'); ?>
    </label>
    <select id="lasso_question" onchange="if(!!jQuery && (jQuery(this).val() == '')){return;} StartChangeLassoQuestionType(jQuery('#lasso_question').val());">
        <?php
        foreach($lasso_form_fields as $lasso_form_field) {
            if(!preg_match('/^\d+$/', $lasso_form_field)) continue;
            $lasso_field_info = $this->lasso_field_info($project_id, $lasso_form_field);
            echo '<option value="'.$lasso_form_field.'">'.$lasso_field_info['label'].'</option>';
        }
        ?>
    </select>
</li>
