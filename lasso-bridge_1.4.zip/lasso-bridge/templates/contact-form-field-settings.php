<div class="control-box lasso-content">
    <fieldset class="scope lasso">
        <table class="form-table">
            <tbody>
            <?php
            if(empty($lasso_form_fields) || !isset($project_id) || !$project_id) {
                echo '<h3>Link to a Lasso Project</h3>';
                echo '<p>Before you can use Lasso-specific fields, you need to <a href="#lasso-settings-panel-tab" id="go-to-lasso-settings">link your form to a Lasso project</a>.</p>';
            } else {
            ?>
                <tr>
                    <th scope="row"><?php echo esc_html(__('Lasso Field', 'lb-plugin-strings')); ?></th>
                    <td>
                        <input type="hidden" name="project_id" value="<?php echo $project_id; ?>" />
                        <fieldset>
                            <legend class="screen-reader-text"><?php echo esc_html(__('Lasso Field', 'lb-plugin-strings')); ?></legend>
                            <label>
                                <input type="hidden" name="name"/>
                                <select class="lasso-field-type">
                                    <?php
                                    foreach($lasso_form_fields as $lasso_form_field) {
                                        $lasso_field_info = $this->lasso_field_info($project_id, $lasso_form_field);
                                        echo '<option value="'.$lasso_form_field.'">'.$lasso_field_info['label'].'</option>';
                                    }
                                    ?>
                                </select>
                            </label>
                        </fieldset>
                        <script type="text/javascript">
                            <?php
                            $javascript = [];
                            foreach($lasso_form_fields as $lasso_form_field) {
                                $lasso_field_info = $this->lasso_field_info($project_id, $lasso_form_field);
                                $javascript[] = '"'.$lasso_form_field.'": '.@json_encode($lasso_field_info);
                            }
                            echo 'window.lasso_form_fields = {';
                            echo implode(',', $javascript);
                            echo '};';
                            ?>
                        </script>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'].'-name' ); ?>">
                            <?php echo esc_html(__('Required', 'lb-plugin-strings')); ?>?
                        </label>
                    </th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text"><?php echo esc_html(__('Required', 'lb-plugin-strings')); ?>?</legend>
                            <label><input type="checkbox" name="required" /> <?php echo esc_html(__('Required', 'lb-plugin-strings')); ?></label>
                        </fieldset>
                    </td>
                </tr>
                <tr class="lasso-setting lasso-setting-input lasso-setting-textarea lasso-setting-date lasso-setting-checkbox lasso-setting-select lasso-setting-multi_select lasso-display-as-proxy-row">
                    <th scope="row" style="white-space: nowrap;">
                        <span class="lasso-setting lasso-setting-select lasso-setting-multi_select"><?php echo __('Display as', 'lb-plugin-strings'); ?></span>
                        <span class="lasso-setting lasso-setting-input lasso-setting-textarea lasso-setting-date lasso-setting-checkbox"><?php echo __('Hidden', 'lb-plugin-strings'); ?></span>
                    </th>
                    <td>
                        <select class="lasso-setting lasso-setting-select lasso-setting-multi_select lasso-display-as-proxy">
                            <option value=""><?php echo  __('Auto', 'lb-plugin-strings'); ?></option>
                            <option value="checkbox" class="lasso-setting lasso-setting-multi_select"><?php echo  __('Checkboxes', 'lb-plugin-strings'); ?></option>
                            <option value="select" class="lasso-setting lasso-setting-select"><?php echo  __('Drop-down menu', 'lb-plugin-strings'); ?></option>
                            <option value="radio" class="lasso-setting lasso-setting-select"><?php echo  __('Radio buttons', 'lb-plugin-strings'); ?></option>
                            <option value="multi_select" class="lasso-setting lasso-setting-multi_select"><?php echo  __('Choice list', 'lb-plugin-strings'); ?></option>
                            <option value="hidden"><?php echo  __('Hidden Value', 'lb-plugin-strings'); ?></option>
                        </select>
                        <div class="lasso-setting lasso-setting-select lasso-setting-multi_select text-small">
                            <span class="text-muted"><?php echo  __('"Auto" will display options as radio buttons or checkboxes for upo to 3 choices, then as a drop-down menu or choice list.', 'lb-plugin-strings'); ?></span>
                        </div>
                        <fieldset class="lasso-setting lasso-setting-input lasso-setting-textarea lasso-setting-date lasso-setting-checkbox">
                            <legend class="screen-reader-text"><?php echo esc_html(__('Hidden', 'lb-plugin-strings')); ?>?</legend>
                            <label><input type="checkbox" value="hidden" class="option lasso-display-as-proxy" /> <?php echo esc_html(__('Hidden', 'lb-plugin-strings')); ?></label>
                        </fieldset>
                        <input type="hidden" value="" name="display-as" class="option" />
                    </td>
                </tr>
                <tr class="lasso-setting lasso-setting-full-address">
                    <th scope="row">
                        <label>
                            <?php echo __('Address Type', 'lb-plugin-strings'); ?>
                        </label>
                    </th>
                    <td>
                        <select class="lasso-address-type">
                            <?php
                            $lasso_field_info = $this->lasso_field_info($project_id, 'addressType');
                            foreach($lasso_field_info['options'] as $option) {
                                echo '<option value="'.$option[$lasso_field_info['option']['value']].'"'.(($option[$lasso_field_info['option']['value']] == $lasso_field_info['default_value']) ? ' selected' : '').'>'.$option[$lasso_field_info['option']['name']].'</option>';
                            }
                            ?>
                        </select>
                        <input type="hidden" value="<?php echo $lasso_field_info['default_value']; ?>" name="address-type" class="option" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'].'-values'); ?>">
                            <span class="lasso-setting lasso-setting-full-address"><?php echo __('Default country', 'lb-plugin-strings'); ?></span>
                            <span class="lasso-setting lasso-setting-input lasso-setting-textarea lasso-setting-date lasso-setting-select lasso-setting-multi_select"><?php echo __('Default value', 'lb-plugin-strings'); ?></span>
                        </label>
                    </th>
                    <td>
                        <input type="text" name="default-value" class="option oneline lasso-setting lasso-setting-full-address lasso-setting-input lasso-setting-textarea lasso-setting-date lasso-setting-select lasso-setting-multi_select" id="<?php echo esc_attr($args['content'].'-values' ); ?>" />
                        <br class="lasso-setting lasso-setting-input lasso-setting-textarea lasso-setting-date" />
                        <label class="lasso-setting lasso-setting-input lasso-setting-textarea lasso-setting-date">
                            <input type="checkbox" name="placeholder" class="option" /> <?php echo esc_html(__( 'Use this text as the placeholder of the field', 'lb-plugin-strings')); ?>
                        </label>
                    </td>
                </tr>

                <tr class="lasso-setting lasso-setting-select lasso-setting-multi_select lasso-setting-checkboxes">
                    <th scope="row">
                        <label>
                            <?php echo esc_html( __('Options', 'lb-plugin-strings')); ?>
                        </label>
                    </th>
                    <td>
                        <fieldset class="lasso-options">
                            <legend class="screen-reader-text"><?php echo esc_html(__('Options', 'lb-plugin-strings')); ?></legend>
                            <div class="lasso-option">
                                <input type="hidden"/>
                                <input type="text" />
                                <div class="text-small">
                                    <span class="text-muted"><span class="raw-value"></span><span class="original-value"></span></span>
                                    <button type="button" class="button lasso-option-remove"><?php echo esc_html(__('Remove', 'lb-plugin-strings')); ?></button>
                                </div>
                            </div>
                        </fieldset>
                        <button type="button" class="button lasso-option-add">+&nbsp;<?php echo esc_html(__('Add', 'lb-plugin-strings')); ?></button>
                    </td>
                </tr>
                <tr class="lasso-setting lasso-setting-checkbox">
                    <th scope="row">
                        <label>
                            <?php echo esc_html(__('Checkbox Text', 'lb-plugin-strings')); ?>
                        </label>
                    </th>
                    <td>
                        <fieldset class="lasso-options">
                            <legend class="screen-reader-text"><?php echo esc_html(__('Checkbox Text', 'lb-plugin-strings')); ?></legend>
                            <div class="lasso-option">
                                <input type="hidden" />
                                <input type="text" />
                            </div>
                        </fieldset>
                    </td>
                </tr>
                <tr class="lasso-setting lasso-setting-date">
                    <th scope="row">
                        <label>
                            <?php echo esc_html(__('Range', 'lb-plugin-strings')); ?>
                        </label>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text"><?php echo esc_html(__('Range', 'lb-plugin-strings')); ?></legend>
                            <label>
                                <?php echo esc_html( __('Min', 'lb-plugin-strings')); ?>
                                <input type="date" name="min" class="date option" />
                            </label>
                            &ndash;
                            <label>
                                <?php echo esc_html(__('Max', 'lb-plugin-strings')); ?>
                                <input type="date" name="max" class="date option" />
                            </label>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'].'-id' ); ?>">
                            <?php echo esc_html(__( 'Id attribute', 'lb-plugin-strings')); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" name="id" class="idvalue oneline option" id="<?php echo esc_attr($args['content'].'-id'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'].'-class'); ?>">
                            <?php echo esc_html(__( 'Class attribute', 'lb-plugin-strings')); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" name="class" class="classvalue oneline option" id="<?php echo esc_attr($args['content'].'-class'); ?>" />
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <textarea name="values" class="values"></textarea>
    </fieldset>
</div>
<?php if(!empty($lasso_form_fields)) { ?>
<div class="insert-box">
	<input type="text" name="lasso" class="tag code" readonly="readonly" onfocus="this.select()" />

	<div class="submitbox">
        <input type="button" class="button button-primary insert-tag" value="<?php echo esc_attr(__('Insert Tag', 'lb-plugin-strings')); ?>" />
	</div>

	<br class="clear" />

	<p class="description mail-tag">
        <label for="<?php echo esc_attr($args['content'].'-mailtag'); ?>">
            <?php echo sprintf(esc_html(__( "To use the value input through this field in a mail field, you need to insert the corresponding mail-tag (%s) into the field on the Mail tab.", 'lb-plugin-strings') ), '<strong><span class="mail-tag"></span></strong>' ); ?>
            <input type="text" class="mail-tag code hidden" readonly="readonly" id="<?php echo esc_attr($args['content'].'-mailtag'); ?>" />
        </label>
    </p>
</div>
<?php } ?>