<?php
trait LassoAPI {
    protected $legacy_mode = false;
    
    protected function api_call($api_key, $path, $param_string = '', $method = 'GET', $headers = array()) {
        $method = strtoupper($method);
        
        $url = 'https://api.lassocrm.com/v1/';
        $url .= $path;
        
        $curl = curl_init($url);
        curl_setopt($curl,CURLOPT_VERBOSE,1);
        curl_setopt($curl,CURLOPT_TIMEOUT,15);
        
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,  2);
        curl_setopt($curl, CURLOPT_FORBID_REUSE, true);
        curl_setopt($curl, CURLOPT_DNS_USE_GLOBAL_CACHE, true); // makes calls faster!
        curl_setopt($curl, CURLOPT_DNS_CACHE_TIMEOUT, 86400); // makes calls faster!
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        
        switch($method) {
            case 'GET':
                if($param_string) {
                    if(!is_string($param_string)) $param_string = http_build_query($param_string);
                    $url .= '?'.$param_string;
                }
            break;
            
            case 'POST':
            case 'PUT':
            case 'DELETE':
                if($method != 'POST') curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method); 
                else curl_setopt($curl, CURLOPT_POST, true);
                // if(!empty($param_string)) curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($param_string));
                if(!empty($param_string)) curl_setopt($curl, CURLOPT_POSTFIELDS, @json_encode($param_string));
            break;
        }

        $headers = array_merge(array(
            'Authorization' => 'Bearer '.$api_key,
            'Content-Type' => 'application/json',
            'accept' => 'application/json'
        ), $headers);
        $http_headers = array();
        foreach($headers as $header => $value) {
            $http_headers[] = $header.': '.$value;
        }
        if(!empty($http_headers)) curl_setopt($curl, CURLOPT_HTTPHEADER, $http_headers);
        curl_setopt($curl, CURLOPT_URL, $url);
    
        $response = curl_exec($curl);
        $response_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        unset($curl);
        
        $response = @json_decode($response);
        /*
        if(isset($response->errorCode)) {
            if(defined('WP_DEBUG') && WP_DEBUG) {
                echo 'API CALL ERROR: '.print_r($response, true);
                exit();
            } else throw new Exception('API CALL ERROR: '.$response->errorMessage);
        }
        */
        return $response;
    }

    protected function standardized_api_list_data($project_id, $posted_data, $fields, $unique = false) {
        $api_data = [];
        if(!empty($fields)) {
            foreach($fields as $key => $legacy_name) {
                if(is_string($key)) $api_name = $key;
                else $api_name = $legacy_name;
                if(array_key_exists($legacy_name, $posted_data) && !!$posted_data[$legacy_name]) {
                    if($unique) $api_data[$api_name] = is_array($posted_data[$legacy_name]) ? (empty($posted_data[$legacy_name]) ? '' : array_pop($posted_data[$legacy_name])) : $posted_data[$legacy_name];
                    else $api_data[$api_name] = is_array($posted_data[$legacy_name]) ? implode(',', $posted_data[$legacy_name]) : $posted_data[$legacy_name];
                }
            }
        }
        return $api_data;
    }
    protected function standardized_api_questions($project_id, $posted_data, $lasso_project = null) {
        if(!$lasso_project) $lasso_project = $this->lasso_project($project_id);
        $api_questions = [];
        if(!empty($posted_data)) {
            $project_questions = $lasso_project->questions;
            foreach($posted_data as $key => $value) {
                if(!$value) continue;
                if(preg_match('/^Q(?:uestions\-)?(\d+)\-?$/i', $key, $matches)) {
                    $question_id = $matches[1];
                    $project_question = null;
                    if(!empty($project_questions)) {
                        foreach($project_questions as $question) {
                            if($question->questionId == $question_id) {
                                $project_question = $question;
                                break;
                            }
                        }
                    }
                    if($project_question) {
                        $api_question = null;
                        if(!empty($api_questions)) {
                            foreach($api_questions as $question) {
                                if($project_question->questionId == $question['questionId']) {
                                    $api_question = $question;
                                    break;
                                }
                            }
                        }
                        if(!$api_question) {
                            $api_question = [
                                'questionId' => $project_question->questionId,
                                'answers' => []
                            ];
                        }
                        if(!is_array($value)) {
                            if(preg_match('/^(checkbox|multi)/i', $project_question->type)) $value = preg_split('/\s*,\s*/', $value);
                            else $value = [$value];
                        }
                        if(!empty($value)) {
                            foreach($value as $answer_value) {
                                $answer = $answer = $answer_value;
                                if(!empty($project_question->answers)) {
                                    foreach($project_question->answers as $project_answer) {
                                        if(($project_answer->answerId == $answer_value) || ($project_answer->answer == $answer_value)) {
                                            $answer = $project_answer->answerId;
                                            break;
                                        }
                                    }
                                    /*
                                    if(!$answer) {
                                        foreach($project_question->answers as $project_answer) {
                                            if(strtolower($project_answer->answer) == strtolower($answer_value)) {
                                                $answer = $project_answer->answerId;
                                                if(!$answer) $answer = $project_answer->answer;
                                                break;
                                            }
                                        }
                                    }
                                    */
                                } //  else $answer = $answer_value;
                                if($answer) {
                                    if(preg_match('/^text$/i', $project_question->type)) $api_question['answers'][] = [ 'answer' => $answer ];
                                    else if(!preg_match('/^\d+$/', $answer)) $api_question['answers'][] = [ 'answer' => $answer ];
                                    else $api_question['answers'][] = [ 'answerId' => $answer ];
                                }
                            }
                        }
                        if(!empty($api_question) && !empty($api_question['answers'])) $api_questions[] = $api_question;
                    }
                }
            }
        }
        return $api_questions;
    }
    protected function standardized_api_many_relationship($project_id, $posted_data, $fields, $property) {
        $api_data = [];
        if(!empty($fields)) {
            foreach($fields as $key => $legacy_name) {
                if(is_string($key)) $api_name = $key;
                else $api_name = $legacy_name;
                $posted_name = $legacy_name;
                if(stripos($posted_name, '||') !== false) {
                    $posted_names = explode('||', $posted_name);
                    foreach($posted_names as $name) {
                        if(array_key_exists($name, $posted_data)) {
                            $posted_name = $name;
                            break;
                        }
                    }
                }
                $posted_main_column_name = preg_replace('/\*$/', '', $posted_name);
                break;
            }
            if(!array_key_exists($posted_main_column_name, $posted_data) || empty($posted_data[$posted_main_column_name])) $posted_main_column_name = $property;
            if(array_key_exists($posted_main_column_name, $posted_data) && !empty($posted_data[$posted_main_column_name])) {
                if(is_array($posted_data[$posted_main_column_name])) {
                    foreach($posted_data[$posted_main_column_name] as $index => $column_value) {
                        $source_array = $posted_data; // [$posted_main_column_name];
// echo 'DEBUG standardized_api_many_relationship: posted_main_column_name='.$posted_main_column_name.', column_value='.print_r($column_value, true)."\n";
                        if(is_array($column_value)) $source_array = $column_value;
                        $api_row = [];
                        $is_complete = true;
                        foreach($fields as $key => $legacy_name) {
                            if(is_string($key)) $api_name = $key;
                            else $api_name = $legacy_name;
                            $is_required = false;
                            $posted_name = preg_replace('/\*$/', '', $legacy_name);
                            if(stripos($posted_name, '||') !== false) {
                                $posted_names = explode('||', $posted_name);
                                foreach($posted_names as $name) {
                                    if(array_key_exists($name, $source_array)) {
                                        $posted_name = $name;
                                        break;
                                    }
                                }
                            }
                            if(($posted_name == 'addressType') && !array_key_exists($posted_name, $source_array) && array_key_exists('type', $source_array)) $posted_name = 'type';

                            $api_name = preg_replace('/^(address|email|phone)Type$/', 'type', $api_name);
                            $api_name = preg_replace('/\*$/', '', $api_name, -1, $is_required);
// echo 'DEBUG standardized_api_many_relationship: api_name='.$api_name.', posted_name='.$posted_name."\n";
                            $source_value = null;
// echo 'DEBUG standardized_api_many_relationship: array_key_exists? '.intVal(!!array_key_exists($posted_name, $source_array))."\n";
                            if(array_key_exists($posted_name, $source_array) && !empty($source_array[$posted_name])) {
// echo 'DEBUG standardized_api_many_relationship: is_array? '.intVal(!!is_array($source_array[$posted_name]))."\n";
                                if(is_array($source_array[$posted_name])) {
                                    $source_value = ($index < count($source_array[$posted_name])) ? $source_array[$posted_name][$index] : null;
                                } else if(!$index) {
                                    // you'll never get both an array and non-array for the same posted_name:
                                    // either it will be an array (and if not same size, case above will take care of it)
                                    // or it will be a non-array - in which case we assign it to the first value and all others are empty
                                    $source_value = $source_array[$posted_name];
                                }
                            }
// echo 'DEBUG standardized_api_many_relationship: source_value='.print_r($source_value, true)."\n";
                            if($is_required && empty($source_value)) $is_complete = false;
                            else if($source_value) {
                                if(isset($api_row[$api_name]) && $api_row[$api_name] && !is_array($api_row[$api_name])) $source_value = [$api_row[$api_name], $source_value];
                                $api_row[$api_name] = $source_value; 
                            }
                        }
                        if(!empty($api_row) && $is_complete) $api_data[] = $api_row;
                    }
                } else {
                    $api_row = [];
                    $is_complete = true;
                    foreach($fields as $key => $legacy_name) {
                        if(is_string($key)) $api_name = $key;
                        else $api_name = $legacy_name;
                        $is_required = false;
                        $posted_name = preg_replace('/\*$/', '', $legacy_name);
                        if(stripos($posted_name, '||') !== false) {
                            $posted_names = explode('||', $posted_name);
                            foreach($posted_names as $name) {
                                if(array_key_exists($name, $posted_data)) {
                                    $posted_name = $name;
                                    break;
                                }
                            }
                        }
                        $api_name = preg_replace('/^(address|email|phone)Type$/', 'type', $api_name);
                        $api_name = preg_replace('/\*$/', '', $api_name, -1, $is_required);
                        if(array_key_exists($posted_name, $posted_data)) {
                            if(empty($posted_data[$posted_name]) && $is_required) $is_complete = false;
                            else if(!empty($posted_data[$posted_name])) {
                                $api_row[$api_name] = $posted_data[$posted_name];
                            }
                        }
                    }
                    if(!empty($api_row) && $is_complete) $api_data[] = $api_row;
                }
            }
        }
        return $api_data;
    }
    protected function standardized_api_data($project_id, $posted_data, $field) {
        $api_data = null;
        switch($field) {
            case 'sendSalesRepAssignmentNotification':
            case 'sendOptInEmail':
                $api_data = array_key_exists($field, $posted_data) && !!preg_match('/^(y|t|1)/i', $posted_data[$field]);
            break;
            case 'thankYouEmailTemplateId':
            case 'rotationId':
                $api_data = array_key_exists($field, $posted_data) ? $posted_data[$field] : '';
                if(is_array($api_data) && !empty($api_data)) $api_data = $api_data[0];
            break;
            default:
                $api_data = array_key_exists($field, $posted_data) ? $posted_data[$field] : '';
            break;
        }
        return $api_data;
    }
    protected function standardized_api_property($project_id, $property, &$api_data, $posted_data, $fields, $lasso_project = null) {
        $data = null;
        switch($property) {
            case 'websiteTracking':
            case 'person':
            case 'rating':
            case 'sourceType':
            case 'secondarySourceType':
            case 'followUpProcess':
                $data = $this->standardized_api_list_data($project_id, $posted_data, $fields, preg_match('/^(rating|(?:secondary)?sourceType)$/i', $property));
                if($property == 'websiteTracking') {
                    if(!$lasso_project) $lasso_project = $this->lasso_project($project_id);
                    $domainAccountId = (isset($lasso_project->websiteTracking) && is_array($lasso_project->websiteTracking) && !empty($lasso_project->websiteTracking)) ? $lasso_project->websiteTracking[0]->domainAccountId : '';
                    if($domainAccountId) {
                        if(empty($data)) $data = [ 'domainAccountId' => $domainAccountId ];
                        else $data['domainAccountId'] = $domainAccountId;
                    }
                }
            break;
            case 'questions':
                $data = $this->standardized_api_questions($project_id, $posted_data, $lasso_project);
            break;
            case 'assignedSalesReps':
            case 'emails':
            case 'email':
            case 'phones':
            case 'phone':
            case 'address':
            case 'addresses':
            case 'notes':
                $data = $this->standardized_api_many_relationship($project_id, $posted_data, $fields, $property);
            break;
            default:
                $data = $this->standardized_api_data($project_id, $posted_data, $property);
            break;
        }
        if(!empty($data) || ($data === false)) $api_data[$property] = $data;
        else unset($api_data[$property]);
    }
    protected function before_registrant_post($project_id, $posted_data, &$api_data) {
        if(!$this->legacy_mode) return;
        $lasso_project = $this->lasso_project($project_id);
        foreach($posted_data as $key => $value) {
            if(!$value) continue;
            if(preg_match('/^Emails(?:\-|\[)([^-\]]+?)(?:\-|\])?$/i', $key, $matches)) {
                switch($matches[1]) {
                    case 'Secondary':
                        $type = 'Personal';
                    break;
                    case 'Tertiary':
                        $type = 'Home';
                    break;
                    default:
                        $type = 'Work';
                    break;
                }
                if(!isset($api_data['emails'])) $api_data['emails'] = [];
                $api_data['emails'][] = [
                    'email' => $value,
                    'type' => $type
                ];
            } else if(preg_match('/^Phones(?:\-|\[)([^-\]]+?)(?:\-|\])?$/i', $key, $matches)) {
                $type = $matches[1];
                if(!preg_match('/^(Home|Work)$/i', $type)) {
                    if(!preg_match('/^Cell$/i', $type)) $type = 'Mobile';
                    else $type = 'Other';
                }
                switch($matches[0]) {
                    case 'Secondary':
                        $type = 'Personal';
                    break;
                    case 'Tertiary':
                        $type = 'Home';
                    break;
                    default:
                        $type = 'Cell';
                    break;
                }
                if(!isset($api_data['phones'])) $api_data['phones'] = [];
                $api_data['phones'][] = [
                    'phone' => $value,
                    'type' => $type
                ];
            } else if(preg_match('/^(Address|City|Province|PostalCode|Country)$/i', $key)) {
                $key = strtolower($key);
                if($key == 'postalcode') $key = 'zipCode';
                else if($key == 'province') $key = 'state';
                if(($key == 'address') || array_key_exists('Address', $posted_data) || array_key_exists('address', $posted_data)) {
                    if(empty($api_data['addresses'])) {
                        $api_data['addresses'][] = [
                            'address' => '',
                            'city' => '',
                            'country' => '',
                            'state' => '',
                            'zipCode' => '',
                            'type' => 'Work'
                        ];
                    }
                    $api_data['addresses'][count($api_data['addresses']) - 1][$key] = $value;    
                } else {

                }
            }
        }
        foreach($api_data as $key => $value) {
            if(!$value) unset($api_data[$key]);
        }
    }
    public function post_registrant_data($project_id, $posted_data, $api_data = null) {
// echo 'DEBUG post_registrant_data: posted_data='.print_r($posted_data, true)."\n";
// echo $project_id.'[post_registrant_data[posted_data='.print_r($posted_data, true).']]'."\n";
        if(!$api_data) {
            $api_data = [
                'websiteTracking' => ['guid'],
                'person' => ['nameTitle', 'firstName', 'lastName', 'company', 'contactPreference', 'gender', 'ssnSin'],
                'rating' => ['rating'],
                'sourceType' => ['sourceType'],
                'secondarySourceType' => ['secondarySourceType'],
                'followUpProcess' => ['followUpProcessId' => 'followUpProcess'],
                'assignedSalesReps' => ['userId' => 'salesReps'],
                'questions' => [],
                'emails' => ['email*', 'type' => 'emailType'],
                // 'email' => ['email*', 'type' => 'emailType'],
                'phones' => ['phone*', 'type' => 'phoneType'],
                'addresses' => ['address*', 'city*', 'state', 'zipCode', 'country*', 'type' => 'addressType'],
                'city' => ['city'],
                'state' => ['state'],
                'province' => ['state'],
                'zipCode' => ['zipCode'],
                'postalCode' => ['zipCode'],
                'country' => ['country'],
                // 'history' => [],
                'notes' => ['note*' => 'note||notes'],
                'sendSalesRepAssignmentNotification' => false,
                'thankYouEmailTemplateId' => '',
                'sendOptInEmail' => false,
                'rotationId' => ''
            ];
        }
        $lasso_project = $this->lasso_project($project_id);
        foreach($api_data as $property => $fields) $this->standardized_api_property($project_id, $property, $api_data, $posted_data, $fields, $lasso_project);
        $this->before_registrant_post($project_id, $posted_data, $api_data);
// echo 'DEBUG API DATA: '.print_r($api_data, true);
// exit();

        $settings = $this->lasso_setting(null, $project_id);
// echo 'DEBUG settings for '.$project_id.': '.print_r($settings, true);
// exit();
        return $this->api_call($settings['api_key'], 'registrants', $api_data, 'POST');
// echo 'DEBUG API RESPONSE: '.print_r($response, true);
// exit();
    }
}
?>