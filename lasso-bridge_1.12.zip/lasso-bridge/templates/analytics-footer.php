<script src="//app.lassocrm.com/analytics.js" type="text/javascript"></script>
<script type="text/javascript">
var LassoCRM = LassoCRM || {};
LassoCRM.trackers = LassoCRM.trackers || [];
var tracker = null;
<?php
    foreach($lasso_projects as $lasso_project) {
        $project_id = $lasso_project->project->projectId;
?>
        try {
            tracker = new LassoAnalytics("<?php echo $plugin_settings[$project_id]['websiteTracking']; ?>");
            tracker._lasso_project_id = "<?php echo $project_id; ?>";
            tracker.setTrackingDomain("//app.lassocrm.com");
            tracker.init();  // initializes the tracker
            tracker.track(); // track() records the page visit with the current page title, to record multiple visits call repeatedly.
            tracker.patchRegistrationForms();
            LassoCRM.trackers.push(tracker);
        } catch(error) {}
<?php
    }
?>
LassoCRM.set_guids = function() {
    if(!jQuery) return;
    for(index in LassoCRM.trackers) {
        tracker = LassoCRM.trackers[index];
        var guid = tracker.readCookie("ut");
        var form = jQuery("form[data-lasso-project-id=" + tracker._lasso_project_id + "]");
        form.find(".gfield.lb_guid input.gform_hidden, input[name='guid']").val(guid);
    }
};
</script>
<script type="text/javascript">
(function(i) {var u =navigator.userAgent;
var e=/*@cc_on!@*/false; var st = setTimeout;if(/webkit/i.test(u)){st(function(){var dr=document.readyState;
if(dr=="loaded"||dr=="complete"){i()}else{st(arguments.callee,10);}},10);}
else if((/mozilla/i.test(u)&&!/(compati)/.test(u)) || (/opera/i.test(u))){
document.addEventListener("DOMContentLoaded",i,false); } else if(e){     (
function(){var t=document.createElement("doc:rdy");try{t.doScroll("left");
i();t=null;}catch(e){st(arguments.callee,0);}})();}else{window.onload=i;}})
(LassoCRM.set_guids);
</script>
