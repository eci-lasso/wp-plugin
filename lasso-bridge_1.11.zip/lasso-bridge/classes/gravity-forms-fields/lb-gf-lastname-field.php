<?php
if(!class_exists('GFForms')) die();

class LB_GF_Lastname_Field extends LB_GF_Text_Field {
    public $type = 'lb_lastName';
    public $inputName = 'lastName';

    public function get_form_editor_field_title() {
        return esc_attr__('Last Name', 'lb-plugin-strings');
    }
}
GF_Fields::register(new LB_GF_Lastname_Field());
