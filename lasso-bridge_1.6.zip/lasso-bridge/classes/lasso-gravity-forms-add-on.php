<?php
if(!class_exists('GFForms')) return;
require_once(preg_replace('/lasso-bridge/', 'gravityforms', LB_PLUGIN_BASE_DIR).'/includes/addon/class-gf-feed-addon.php');
if(method_exists('GFCommon', 'glob_require_once')) {
    GFCommon::glob_require_once('/lb-gf-base-*.php', LB_PLUGIN_BASE_DIR.'/classes/gravity-forms-fields');
    GFCommon::glob_require_once('/lb-gf-*.php', LB_PLUGIN_BASE_DIR.'/classes/gravity-forms-fields');    
}

GFForms::include_addon_framework();

require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoSettings.php');

class LassoGravityFormsAddOn extends GFFeedAddOn {
    use LassoSettings;
    
    const GROUP_NAME = 'lasso-gf-buttons';
    
    protected $_version = LB_PLUGIN_VERSION;
    protected $_min_gravityforms_version = '2.4';
    protected $_slug = 'lassobridgeaddon';
    protected $_path = 'lasso-bridge/lasso-bridge.php';
    protected $_full_path = __FILE__;
    protected $_title = 'Lasso Add-On for Gravity Forms';
    protected $_short_title = 'Lasso Add-On';

    static private $_instance = null;
    static public function get_instance() {
        if(self::$_instance == null) self::$_instance = new LassoGravityFormsAddOn();
        return self::$_instance;
    }

	private function upgrade_base($previous_version) {
        /*
        if(!$previous_version || (floatVal($previous_version) < 1.2)) {
            $previous_version = 1.2;
        }
        */
	}
    protected function menu_page_url($args = []) {
        $args = wp_parse_args($args, [ 'page' => 'gf_settings', 'subview' => $this->_slug ]);
        $url = menu_page_url('forms_page_gf_settings', false);
        if(!empty($args)) $url = add_query_arg($args, $url);

        return $url;
    }

    public function init() {
        parent::init();
        if($this->meets_minimum_requirements()) {
            add_filter('gform_form_tag', array($this, 'gform_form_tag'), 10, 2);
            add_filter('gform_field_css_class', array($this, 'gform_field_css_class'), 10, 3);
            add_filter('gform_predefined_choices', array($this, 'gform_predefined_choices'));
            add_action('gform_field_standard_settings', array($this, 'gform_field_standard_settings'), 10, 2);    
            add_filter('gform_add_field_buttons', array($this, 'gform_add_field_buttons'));
            add_filter('gform_gf_field_create', array($this, 'gform_gf_field_create'), 10, 2);
            add_filter('gform_enable_legacy_markup', array($this, 'gform_enable_legacy_markup'), 10, 2);
            add_filter('gform_pre_validation', array($this, 'gform_pre_validation'));
            add_action('gform_after_save_form', array($this, 'gform_after_save_form'), 10, 3);    
        }
    }
	public function init_admin() {
		parent::init_admin();
        if($this->meets_minimum_requirements()) {
            add_action('admin_enqueue_scripts', array($this, 'maybe_enqueue_scripts'));
            add_action('gform_editor_js', array($this, 'gform_editor_js'));
        }
    }
	public function setup() {
        if($this->meets_minimum_requirements()) {
            $installed_version = get_option('lasso-gravity-forms-add-on-version');
            if ($installed_version != $this->_version) {
                $this->upgrade_base($installed_version);
                update_option('lasso-gravity-forms-add-on-version', $this->_version);
            }
        }
        parent::setup();
	}
	public function post_gravityforms_upgrade($db_version, $previous_db_version, $force_upgrade) {
		if($force_upgrade) {
            $installed_version = get_option('lasso-gravity-forms-add-on-version');
            $this->upgrade_base($installed_version);
            update_option('lasso-gravity-forms-add-on-version', $this->_version);
		}

		parent::post_gravityforms_upgrade($db_version, $previous_db_version, $force_upgrade);
	}

    public function maybe_enqueue_scripts($hook_suffix) {
        global $lb_plugin;
        if($this->is_plugin_settings($this->_slug) || ((rgget('page') == 'gf_edit_forms') && !rgget('view'))) {
            wp_enqueue_style('lb-plugin-css', $lb_plugin->asset_url('style.css'));
            wp_enqueue_script('lb-plugin-js', $lb_plugin->asset_url('script.js'), array('jquery'));
        }
    }

    public function plugin_settings_fields() {
        if(!$this->is_active()) {
            return [
                [
                    'title'  => __('Link a Lasso Project', 'lb-plugin-strings'),
                    'fields' => [
                        [
                            'label' => __('Enter the project\'s API Key', 'lb-plugin-strings'),
                            'type' => 'text',
                            'name' => 'api_key',
                            'class' => 'medium',
                        ]
                    ]
                ]
            ];
        }

        if(isset($_REQUEST['project_id'])) {
            $project_id = intVal($_REQUEST['project_id']);
            if($project_id) {
                $lasso_project = $this->lasso_project($project_id);
                $settings = $this->lasso_setting($lasso_project->project->projectId);
                $title = $lasso_project->project->name.' ('.$this->mask_value($settings['api_key'], 4, 4).')';
            } else {
                $title = __('Link a New Lasso Project', 'lb-plugin-strings');
            }

            return [
                [
                    'title'  => $title,
                    // 'class' => 'gform-settings-panel--no-padding gform-settings-panel--license-details',
                    'fields' => [
                        [
                            'name' => 'lasso-project',
                            'type' => 'html',
                            'html' => [$this, 'project_editor']
                        ]
                    ]
                ]
            ];
        }

        return [
            [
                'title'  => __( 'Lasso Projects', 'gravityforms' ),
                // 'class' => 'gform-settings-panel--no-padding gform-settings-panel--license-details',
                'fields' => [
                    [
                        'name' => 'lasso-projects',
                        'type' => 'html',
                        'html' => [$this, 'projects_list']
                    ]
                ]
            ]
        ];

        $plugin_settings = $this->lasso_setting();
        $settings_fields = [];
        foreach($plugin_settings as $project_id => $settings) {
            $lasso_project = $this->lasso_project($project_id);

            $fields = [
                [
                    'type' => 'hidden',
                    'name' => '_noop',
                    'id' => 'remove-api-key-field'
                ]
            ];
            $lasso_form_fields = $this->lasso_setting_fields($project_id);
            foreach($lasso_form_fields as $setting_id) {
                if(($setting_id == 'api_key') || !isset($settings[$setting_id])) continue;
                $lasso_field_info = $this->lasso_field_info($project_id, $setting_id);
                $setting_value = $settings[$setting_id];
                $is_multi_select = false;
                $is_checkbox = false;
                
                switch($lasso_field_info['tag']) {
                    case 'select':
                    case 'textarea':
                    case 'checkbox':
                    case 'radio':
                        $type = $lasso_field_info['tag'];
                        if($lasso_field_info['tag'] == 'checkbox') {
                            $is_checkbox = true;
                            $is_multi_select = true;
                        }
                    break;
                    case 'multi_select':
                        $type = 'select';
                        $is_multi_select = true;
                    break;
                    default:
                        $type = 'text';
                    break;
                }
                $field = [
                    'label' => $lasso_field_info['default_label'],
                    'type' => $type,
                    'id' => $setting_id,
                    'name' => $setting_id.($is_multi_select ? '[]' : ''),
                    'class' => 'medium'
                ];
                if(!!$lasso_field_info['description']) $field['tooltip'] = $lasso_field_info['description'];
                if($is_multi_select) $field['multiple'] = 'multiple';
                if(($type == 'select') || ($type == 'checkbox')) {
                    $value_field = $lasso_field_info['option']['value'];
                    $name_field = $lasso_field_info['option']['name'];
                    $field['choices'] = [];
                    if(!$is_multi_select && !$is_checkbox) {
                        $field['choices'][] = [ 'label' => __('Set by a form field', 'lb-plugin-strings'), 'value' => 0 ];
                    }
                    if(!empty($lasso_field_info['options'])) {
                        foreach($lasso_field_info['options'] as $option) {
                            if(is_array($option)) $option = @json_decode(@json_encode($option));
                            $choice = [ 'label' => $option->$name_field, 'value' => $option->$value_field ];
                            if($is_checkbox) {
                                $choice['name'] = $setting_id;
                            }
                            $field['choices'][] = $choice;
                        }
                    }
                }
                $fields[] = $field;
            }

            // remove key button _x('Unlink this project', 'API keys', 'lb-plugin-strings'),
            $fields[] = [
                'type' => 'button',
                'name' => 'save',
                'value' => _x('Unlink this project', 'API keys', 'lb-plugin-strings'),
                'class' => 'medium'
            ];

            $fields[] = [
                'type' => 'button',
                'name' => 'reset',
                'class' => 'small'
            ];
    
            $settings_fields[] = [
                'title'  => $lasso_project->project->name,
                'description' => sprintf('<div class="alert %s" role="alert">%s</div>', 'gforms_note_success', 'API Key: '.$this->mask_value($settings['api_key'], 4, 4)),
                'fields' => $fields
            ];
            $settings_fields[] = [
                'title'  => $lasso_project->project->name,
                'description' => sprintf('<div class="alert %s" role="alert">%s</div>', 'gforms_note_success', 'API Key: '.$this->mask_value($settings['api_key'], 4, 4)),
                'fields' => $fields
            ];
        }
        
        return $settings_fields;
    }
	public function projects_table() {
		return new LB_GF_Projects_List_Table($this->lasso_setting(), $this->_slug, $this);
	}
    public function projects_list() {
        $action = rgpost('action');
        $object_id = rgpost('action_argument');

        switch ($action) {
            case 'delete':
                $this->reset_lasso_settings($object_id);
            break;
        }
        $projects_table = $this->projects_table();
        $projects_table->prepare_items();
        $projects_table->display();
    ?>

        <input type="hidden" value="gf_settings" name="page">
        <input type="hidden" value="<?php echo esc_attr($this->_slug); ?>" name="subview">
        <input id="action" type="hidden" value="" name="action">
        <input id="action_argument" type="hidden" value="" name="action_argument">
        <?php wp_nonce_field('lasso_projects_list', 'lasso_projects_list'); ?>
    <?php
    }
    public function project_editor() {
        $project_id = intVal($_REQUEST['project_id']);
        if($project_id) {
            $lasso_project = $this->lasso_project($project_id);
            $settings = $this->lasso_setting($project_id);
            echo '<input type="hidden" name="project_id" value="'.$project_id.'" />';
        }
        include(dirname(__FILE__).'/../templates/settings.php');
    }
	public function feed_list_page($form = null) {
        $settings = $this->lasso_setting();
        if($settings) parent::feed_list_page($form);
        else {
        ?>
		<div class="gform-settings-panel">
			<header class="gform-settings-panel__header">
				<h4 class="gform-settings-panel__title"><span><?php echo $this->feed_list_title() ?></span></h4>
			</header>

			<div class="gform-settings-panel__content">
                <a href="<?php echo admin_url( 'admin.php' ).'?page=gf_settings&subview='.$this->_slug; ?>">
                    <?php echo __('First, you need to set-up at least one Lasso project...', 'lb-plugin-strings'); ?>
                </a>
			</div>
		</div>
        <?php
        }
    }
    public function feed_settings_fields() {
        $feed = $this->get_current_feed();
        $count_projects = $this->lasso_auto_assign_project_id($feed['meta']);
        $settings = $this->lasso_setting();
        if($count_projects > 1) {
            if(!$feed || !isset($feed['meta']) || !isset($feed['meta']['project_id']) || !$feed['meta']['project_id']) {
                uasort($settings, function($project_a, $project_b) {
                    return strcmp($project_a['project_name'], $project_b['project_name']);
                });
                $choices = array_map(function($project) {
                    return [ 'label' => $project['project_name'], 'value' => $project['project_id'] ];
                }, array_values($settings));
                $settings_fields = [
                    [
                        'title'  => __('Lasso Form Settings', 'lb-plugin-strings'),
                        'fields' => [
                            [
                                'label' => 'Lasso Project',
                                'type' => 'select',
                                'name' => 'project_id',
                                'default_value' => __('Default Feed', 'lb-plugin-strings'),
                                'class' => 'medium',
                                'description' => __('First, you need to link your form to a Lasso project.', 'lb-plugin-strings'),
                                'choices' => $choices,
                                'default_value' => $feed['meta']['project_id']
                            ]
                        ]
                    ]
                ];
                return $settings_fields;
            }
        }
        $settings_fields = [
            [
                'title'  => __('Lasso Form Settings', 'lb-plugin-strings'),
                'fields' => [
                    [
                        'type' => 'hidden',
                        'name' => 'project_id',
                        'value' => $feed['meta']['project_id']
                    ],
                    [
                        'label' => 'Feed Name',
                        'type' => 'text',
                        'name' => 'feedName',
                        'default_value' => __('Default Feed', 'lb-plugin-strings'),
                        'class' => 'medium',
                        'description' => __('Name your feed - for the feeds list only, this will not appear anywhere else.', 'lb-plugin-strings')
                    ]
                ]
            ]
        ];
        $lasso_setting_fields = $this->lasso_setting_fields($feed['meta']['project_id']);
        foreach($lasso_setting_fields as $setting_id) {
            if(($setting_id == 'api_key') || ($setting_id == 'project_id') || ($setting_id == 'project_name') || ($setting_id == 'legacy_mode')) continue;
            $lasso_field_info = $this->lasso_field_info($feed['meta']['project_id'], $setting_id);
            $setting_value = array_key_exists($setting_id, $settings) ? $settings[$setting_id] : (isset($lasso_field_info['default_value']) ? $lasso_field_info['default_value'] : '');
            $is_multi_select = false;
            $is_checkbox = false;
            
            switch($lasso_field_info['tag']) {
                case 'select':
                case 'textarea':
                case 'checkbox':
                case 'radio':
                    $type = $lasso_field_info['tag'];
                    if($lasso_field_info['tag'] == 'checkbox') {
                        $is_checkbox = true;
                        $is_multi_select = true;
                    }
                break;
                case 'multi_select':
                    $type = 'select';
                    $is_multi_select = true;
                break;
                default:
                    $type = 'text';
                break;
            }
            $field = [
                'label' => $lasso_field_info['label'],
                'type' => $type,
                'id' => $setting_id,
                'name' => $setting_id.($is_multi_select ? '[]' : ''),
                'class' => 'medium'
            ];
            if(!!$lasso_field_info['description']) $field['tooltip'] = $lasso_field_info['description'];
            if($is_multi_select) $field['multiple'] = 'multiple';
            if(($type == 'select') || ($type == 'checkbox')) {
                $value_field = $lasso_field_info['option']['value'];
                $name_field = $lasso_field_info['option']['name'];
                $field['choices'] = [];
                if(!$is_multi_select && !$is_checkbox) {
                    $field['choices'][] = [ 'label' => __('Set by a form field', 'lb-plugin-strings'), 'value' => 0 ];
                }
                if(!empty($lasso_field_info['options'])) {
                    foreach($lasso_field_info['options'] as $option) {
                        if(is_array($option)) $option = @json_decode(@json_encode($option));
                        $choice = [ 'label' => $option->$name_field, 'value' => $option->$value_field ];
                        if($is_checkbox) {
                            $choice['name'] = $setting_id;
                        }
                        if($option->$value_field == $setting_value) $choice['default_value'] = 1;
                        $field['choices'][] = $choice;
                    }
                }
            }
            $field['default_value'] = $setting_value;
            $settings_fields[0]['fields'][] = $field;
        }
        $settings_fields[0]['fields'][] = [
            'type'  => 'feed_condition',
            'name'  => 'send_to_lasso',
            'label' => 'Conditionally Send To Lasso?',
            'checkbox_label' => 'Conditionally Send To Lasso',
            'instructions' => 'Send to Lasso only if',
        ];
// echo 'DEBUG: settings='.print_r($settings, true).', settings_fields='.print_r($settings_fields, true);
// exit();
        return $settings_fields;
    }
    public function feed_list_columns() {
        return array(
            'feedName' => 'Name',
        );
    }
    public function process_feed($feed, $entry, $form) {
// echo '[JEAN process_feed[form='.print_r($form, true).']]'."\n";
// echo '[JEAN process_feed[entry='.print_r($entry, true).']]'."\n";
        if(isset($form['fields']) && !empty($form['fields'])) {
            $posted_data = $feed['meta'];
            foreach($form['fields'] as $form_field) {
                $field = GFFormsModel::get_field($form, $form_field['id']);
// echo '[JEAN process_feed[field='.print_r($field, true).']]'."\n";
                $posted_name = $field->inputName;
                if(!preg_match('/^lb_/', $field->type)) {
                    $this->legacy_mode = !!$form_field['lassoID'];
                    $posted_name = $this->legacy_mode ? $form_field['lassoID'] : '';
                } else if($field->type == 'lb_question') $posted_name = 'Q'.$posted_name;
// echo '[JEAN process_feed[posted_name='.print_r($posted_name, true).']]'."\n";
                if(!$posted_name) continue;
                $api_data = null;
                if(!$this->legacy_mode) {
                    $append_block_value = function($block_posted_name) use($field, $entry, $form_field, &$posted_data) {
                        $block_value = $field->get_value_export($entry, $form_field['id']);
                        if(!empty($block_value)) {
                            if(!array_key_exists($block_posted_name, $posted_data)) $posted_data[$block_posted_name] = [];
                            $posted_data[$block_posted_name][] = $block_value;
                        }
                    };
                    switch($posted_name) {
                        case 'addressBlock':
                            $append_block_value('address');
                            // $posted_data = array_merge($posted_data, GF_Fields::get('lb_address_block')->get_value_export($entry, $form_field['id']));
                        break;
                        case 'emailBlock':
                            $append_block_value('email');
                        break;
                        case 'phoneBlock':
                            $append_block_value('phone');
                        break;
                        case 'nameBlock':
                            $posted_data = array_merge($posted_data, GF_Fields::get('lb_name')->get_value_export($entry, $form_field['id']));
                        break;
                        default:
// echo 'DEBUG get_field_value ('.$form_field['id'].' - '.$posted_name.'): '.print_r($this->get_field_value($form, $entry, $form_field['id']), true)."\n";
                            if(array_key_exists($posted_name, $posted_data) && !is_array($posted_data[$posted_name])) $posted_data[$posted_name] = [$posted_data[$posted_name]];
                            if(array_key_exists($posted_name, $posted_data) && is_array($posted_data[$posted_name])) $posted_data[$posted_name][] = $this->get_field_value($form, $entry, $form_field['id']);
                            else $posted_data[$posted_name] = $this->get_field_value($form, $entry, $form_field['id']);
// echo 'DEBUG get_field_value ('.$form_field['id'].' - '.$posted_name.'): '.print_r($posted_data, true)."\n";
                        break;
                    }
                } else {
                    $subvalue = function($inputs, $value_label) use($entry) {
                        $value = '';
                        
                        if(!empty($inputs)) {
                            foreach($inputs as $input) {
                                if($input['label'] == $value_label) {
                                    $value = $entry[strval($input['id'])];
                                    break;
                                }
                            }
                        }
                        
                        return $value;
                    };

                    $data = [];
                    $value = $this->get_field_value($form, $entry, $field['id']);
                    if(!preg_match('/^Questions\-/', $posted_name)) {
                        do {
                            $posted_name = preg_replace('/\-([^\-]*?)(\-|$)/', '[$1]$2', $posted_name);
                        } while(preg_match('/\-([^\-]*?)(\-|$)/', $posted_name));    
                    }
                        
                    if($posted_name == 'FullName') {
                        $data = [
                            'FirstName' => $subvalue($field['inputs'], 'First'),
                            'LastName' => $subvalue($field['inputs'], 'Last')
                        ];
                    } else {
                        $data[$posted_name] = $value;
                    }
                    
                    foreach($data as $key => $value) {
                        if(is_array($value)) {
                            if(preg_match('/\[\]$/', $key)) { // Both GF and Lasso fields are arrays
                                $key = preg_replace('/\[\]$/', '', $key);
                                $posted_data[$key] = $value;
                            } else { // GF is an array && Lasso field is NOT an array
                                $new_value = '';
                                if(!empty($value)) {
                                    foreach($value as $field_id => $mappings) {
                                        if(preg_match('/^0$/', $field_id)) $new_value = $mappings;
                                        else {
                                            $field_id = preg_replace('/\-([^\-]+)(\-|$)/', '[$1]$2', $field_id);
                                            if(isset($data[$field_id]) && isset($mappings[$data[$field_id]])) $new_value .= $mappings[$data[$field_id]];
                                        }
                                    }
                                }
                                $posted_data[$key] = $new_value;
                            }
                        } else $posted_data[$key] = $value;
                    }
                    $api_data = [
                        'websiteTracking' => ['guid'],
                        'person' => ['nameTitle', 'firstName', 'lastName', 'company', 'contactPreference', 'gender', 'ssnSin'],
                        'rating' => ['rating'],
                        'sourceType' => ['sourceType'],
                        'secondarySourceType' => ['secondarySourceType'],
                        'followUpProcess' => ['followUpProcessId'],
                        'assignedSalesReps' => ['userId'],
                        'questions' => [],
                        'emails' => ['email*', 'type' => 'emailType'],
                        // 'email' => ['email*', 'type' => 'emailType'],
                        'phones' => ['phone*', 'type' => 'phoneType'],
                        'addresses' => ['address', 'city', 'state', 'zipCode', 'country', 'type' => 'addressType'],
                        // 'history' => [],
                        'notes' => ['note*' => 'note||notes'],
                        'sendSalesRepAssignmentNotification' => false,
                        'thankYouEmailTemplateId' => '',
                        'sendOptInEmail' => false,
                        'rotationId' => ''
                    ];
                }
            }
//echo 'DEBUG POSTED DATA ('.intVal(!!$this->legacy_mode).'): '.print_r($posted_data, true)."\n";
// exit();

            $form_properties = GFFormsModel::get_form_meta($form['id']);
// echo 'DEBUG FEED META ('.intVal(!!$this->legacy_mode).'): '.print_r($feed['meta'], true)."\n";
// exit();
            $posted_data = array_merge($feed['meta'], $posted_data);
// echo 'DEBUG POSTED DATA ('.intVal(!!$this->legacy_mode).') => '.print_r($posted_data, true)."\n";
// exit();
            $this->lasso_auto_assign_project_id($form_properties);
            $this->post_registrant_data($posted_data['project_id'], $posted_data, $api_data);
            $this->legacy_mode = false;
        }
    }

    private function form_project_id($form = null) {
        if(!$form || is_bool($form)) $form = $this->get_current_form();
        else if(!is_array($form)) $form = GFAPI::get_form($form);
        $feeds = GFAPI::get_feeds(null, $form['id'], $this->_slug);
        if(!empty($feeds) && !is_wp_error($feeds)) {
            $feed = $feeds[0];
            if($feed && isset($feed['meta']) && isset($feed['meta']['project_id']) && $feed['meta']['project_id']) return $feed['meta']['project_id'];
        }
        return 0;
    }
    public function gform_form_tag($html, $form) {
        $project_id = $this->form_project_id($form);
        $html = preg_replace('/>$/', ' data-lasso-project-id="'.$project_id.'">', $html);
        return $html;
    }
    public function gform_editor_js() {
        $project_id = $this->form_project_id();
        if($project_id) {
            $lasso_form_fields = $this->lasso_form_fields($project_id);
            $javascript = [];
            foreach($lasso_form_fields as $lasso_form_field) {
                $lasso_field_info = $this->lasso_field_info($project_id, $lasso_form_field);
                $javascript[] = '"'.$lasso_form_field.'": '.@json_encode($lasso_field_info);
            }
        }
        echo '<script type="text/javascript">'.PHP_EOL;
        if($project_id) {
            echo 'window.lasso_form_fields = {'.PHP_EOL;
            echo implode(',', $javascript).PHP_EOL;
            echo '};'.PHP_EOL;
        }
        echo 'window.lasso_menu_page_url = "'.$this->menu_page_url([ 'page' => 'gf_edit_forms', 'view' => 'settings', 'id' => '{id}' ]).'";'.PHP_EOL;
        echo '</script>'.PHP_EOL;
    }
    public function gform_field_css_class($css_class, $field, $form) {
        if(!$css_class || !preg_match('/\s+?'.preg_quote($field->type, '/').'/', $css_class)) $css_class .= ' '.$field->type;
        return $css_class;
    }
    public function gform_predefined_choices($predefined_choices) {
        $project_id = $this->form_project_id();

        $lasso_form_fields = $this->lasso_form_fields($project_id);
        foreach($lasso_form_fields as $lasso_form_field) {
            $lasso_field_info = $this->lasso_field_info($project_id, $lasso_form_field);
            if(!empty($lasso_field_info['options'])) {
                $value_field = $lasso_field_info['option']['value'];
                $name_field = $lasso_field_info['option']['name'];
                $choices = [];
                foreach($lasso_field_info['options'] as $option) {
                    if(is_array($option)) $option = @json_decode(@json_encode($option));
                    $choices[] = $option->$name_field.'|'.$option->$value_field;
                }
                $predefined_choices['Lasso '.$lasso_field_info['label']] = $choices;
            }
        }
        return $predefined_choices;
    }

	public function get_plugin_settings() {
        // load our plugin settings, in case they were changed via another UI (like CF7)
		return $this->lasso_setting();
	}
	public function update_plugin_settings($settings) {
        $redirect_to = null;
        $api_key = isset($_POST['_gform_setting_api_key']) ? $_POST['_gform_setting_api_key'] : (isset($_POST['api_key']) ? $_POST['api_key'] : null);
        if($api_key !== null) {
            $lasso_project = $this->lasso_set_api_key($api_key);
            if($lasso_project) {
                $redirect_to = $this->menu_page_url([
                    'project_id' => $lasso_project->project->projectId,
                    'subview' => $this->_slug
                ]);
            } else if($lasso_project === false) {
                $redirect_to = $this->menu_page_url([
                    'message' => 'unauthorized'
                ]);
            } else if(!$lasso_project) {
                $redirect_to = $this->menu_page_url([
                    'message' => 'invalid'
                ]);
            }
        } else if(isset($_POST['project_id'])) {
            if(!empty($_POST['reset'])) {
                $this->reset_lasso_settings($_POST['project_id']);
            } else {
                $this->set_lasso_settings($_POST['project_id'], $_POST);
            }
            $redirect_to = $this->menu_page_url();
        }
        if($redirect_to) wp_safe_redirect($redirect_to);
    }
    public function gform_field_standard_settings($position, $form_id) {
        if($position == 0) {
            $project_id = $this->form_project_id($form_id);
            $lasso_form_fields = $this->lasso_form_fields($project_id);
            include(dirname(__FILE__).'/../templates/gravityform-field-settings.php');
        }
    }
    public function gform_add_field_buttons($field_groups) {
        foreach($field_groups as &$field_group) {
            if($field_group['name'] == LassoGravityFormsAddOn::GROUP_NAME) {
                usort($field_group['fields'], function($field_a, $field_b) {
                    return strcmp($field_a['value'], $field_b['value']);
                });
                break;
            }
        }
        return $field_groups;
    }
    public function gform_gf_field_create($field, $properties) {
        $class_name = null;

        $type = isset($properties['type']) ? $properties['type'] : '';
        if($type == 'lb_address_block') $class_name = 'LB_GF_Addressblock_Field';
        else if($type == 'lb_email') $class_name = 'LB_GF_Email_Field';
        else if($type == 'lb_guid') $class_name = 'LB_GF_Guid_Field';
        else if($type == 'lb_name') $class_name = 'LB_GF_Name_Field';
        else if($type == 'lb_phone') $class_name = 'LB_GF_Phone_Field';
        else if($type == 'lb_question') $class_name = 'LB_GF_Question_Field';
		if($class_name) {
            $field = new $class_name($properties);
        }
        
        return $field;
    }
    public function gform_enable_legacy_markup($is_enabled, $form) {
        if($is_enabled) {
            $project_id = $this->form_project_id($form);
            $is_enabled = !$project_id;
        }
        return $is_enabled;
    }
    public function gform_pre_validation($form) {
        foreach($form['fields'] as &$field) {
            if(preg_match('/^lb_/', $field->type)) $field->noDuplicates = false;
        }
        return $form;
    }
    public function gform_after_save_form($form_meta, $is_new, $deleted_fields) {
        if(!empty($form_meta['fields'])) {
            $guid = false;
            $lasso_enabled = false;
            foreach($form_meta['fields'] as $field) {
                if(preg_match('/^lb_/', $field->type)) $lasso_enabled = true;
                if(($field->type == 'lb_guid') && ($field->inputName == 'guid')) {
                    $guid = true;
                    break;
                }
            }
            if($lasso_enabled && !$guid) {
                $form_meta['fields'][] = GF_Fields::create([
                    'type' => 'lb_guid',
                    // 'id' => 1, // count($form_meta['fields']) + 10,
                    'label' => 'guid',
                    'inputName' => 'guid',
                    'formId' => $form_meta['id']
                ]);
                $form_meta['is_active'] = true;
                GFAPI::update_form($form_meta);
            }
        }
    }
}

class LB_GF_Projects_List_Table extends WP_List_Table {
    private $_columns;
	private $_projects;
	private $_slug;
	private $_addon_class;

	function __construct($projects, $slug, $addon_class) {
        $this->_projects = $projects;
		$this->_slug = $slug;
		$this->_addon_class = $addon_class;

		$this->_columns = [
            'project_name' => 'Name'
        ];
        $standard_cols = [];
        if(count($this->_projects) > 1) $standard_cols['cb'] = esc_html__('Checkbox', 'gravityforms');

		$all_cols = array_merge($standard_cols, $this->_columns);

		$this->_column_headers = array(
			$all_cols,
			[],
			[],
			rgar(array_keys($all_cols), 2)
		);

		parent::__construct(
			array(
				'singular' => esc_html__('project', 'gravityforms'),
				'plural' => esc_html__('projects', 'gravityforms'),
				'ajax' => false,
			)
		);
	}

	function prepare_items() {
		$this->items = isset($this->_projects) ? array_values($this->_projects) : [];
	}
	function get_columns() {
		return $this->_column_headers[0];
	}
	function get_bulk_actions() {
        return [];
	}

	function column_default($item, $column) {
        $value = $this->get_column_value($item, $column);

		$columns = array_keys($this->_columns);
		if(is_array($columns) && (count($columns) > 0) && ($columns[0] == $column)) $value = $this->add_action_links($item, $column, $value);

		return $value;
	}
	function column_cb( $item ) {
		$project_id = rgar($item, 'id');

		return sprintf(
			'<input type="checkbox" name="project_ids[]" value="%s" />', esc_attr($project_id)
		);
	}

	function add_action_links($item, $column, $value) {
		$edit_url = add_query_arg(array('project_id' => $item['project_id']));
		$actions = [
			'edit' => '<a href="'.esc_url($edit_url).'">'.esc_html__('Edit', 'gravityforms').'</a>'
        ];
        if(count($this->items) > 1) $actions['delete'] = '<a href="javascript:void(0);" data-project-id="'.$item['project_id'].'" data-project-name="'.$item['project_name'].'" class="submitdelete" style="cursor:pointer;">'.esc_html__('Unlink this project', 'gravityforms').'</a>';
		return $value.' <span style="color: #276a52;">('.esc_html($this->mask_value($item['api_key'], 4, 4)).')</span>'.$this->row_actions($actions);
	}

    protected function extra_tablenav($which) {
		printf(
			'<div class="alignright"><a href="%s" class="button">%s</a></div>',
			esc_url(add_query_arg(array('project_id' => 0))),
			$this->has_items() ? esc_html__('Link another Lasso Project', 'lb-plugin-strings') : esc_html__('Link a Lasso Project', 'lb-plugin-strings')
		);
	}

	protected function display_tablenav( $which ) {
		if(!$this->has_items()) return;
		parent::display_tablenav($which);
	}

	public function get_column_value($item, $column) {
		if(array_key_exists($column, $item)) return $item[$column];
        return $column;
	}
}
?>