<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoGravityFormField.php');

class LB_GF_Question_Field extends GF_Field {
    use LassoGravityFormField;
    
    public $type = 'lb_question';
	public $allowsPrepopulate = true;
    // public $inputType = 'select';
    // public $inputName = 'sourceType';

    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted custom question to send to Lasso', 'lb-plugin-strings');
    }
    public function get_form_editor_field_title() {
        return esc_attr__('Custom Question', 'lb-plugin-strings');
    }
	public function get_form_editor_field_icon() {
		return 'gform-icon--question-mark';
	}
	public function get_form_editor_field_settings() {
		return array(
			'lasso_question_setting',
			'conditional_logic_field_setting',
			'prepopulate_field_setting',
			'error_message_setting',
			'label_setting',
			'label_placement_setting',
			'admin_label_setting',
			'size_setting',
			'rules_setting',
			'visibility_setting',
			'duplicate_setting',
			'description_setting',
			'css_class_setting',
		);
	}
    protected function form_editor_inline_script_content($lasso_field_info, &$function_lines, $project_id) {
		$project_id = $this->form_project_id();
		$lasso_form_fields = $this->lasso_form_fields($project_id);
		$questions = array_values(preg_grep('/^\d+$/i', $lasso_form_fields));
// echo '[JEAN form_editor_inline_script_content[lasso_form_questions='.print_r($questions, true).']]'."\n";
		$lasso_field_info = $this->lasso_field_info($project_id, empty($questions) ? $lasso_form_fields[0] : $questions[0]);
// echo '[JEAN form_editor_inline_script_content[lasso_field_info='.print_r($lasso_field_info, true).']]'."\n";
		$this->inputType = $lasso_field_info['tag'];

		$function_lines = [ 'field.label = "'.$lasso_field_info['label'].'";' ];

		if(!empty($lasso_field_info['options'])) {
			$choices = [];
			$value_field = $lasso_field_info['option']['value'];
			$name_field = $lasso_field_info['option']['name'];
			foreach($lasso_field_info['options'] as $option) {
				if(is_array($option)) $option = @json_decode(@json_encode($option));
				$choices[] = 'new Choice("'.$option->$name_field.'", "'.$option->$value_field.'")';
			}
	
			$function_lines[] = 'field.choices = ['.implode(', ', $choices).'];';
			$function_lines[] = 'field.enableChoiceValue = true;';
		}
    }
	private function get_field_proxy($form_id, $value = null) {
		global $wpdb;
// echo '[JEAN get_field_proxy[value='.print_r($value, true).']'.$this->id.']'."\n";
		$table_name = GFFormsModel::get_meta_table_name();
		$meta = $wpdb->get_row($wpdb->prepare("SELECT display_meta, notifications FROM {$table_name} WHERE form_id=%d", $form_id), ARRAY_A);
		$meta = GFFormsModel::unserialize(rgar($meta, 'display_meta'));
// echo '[JEAN get_field_proxy[meta='.print_r($meta, true).']'.$this->id.']'."\n";
		if(!$meta) return [];
		$properties = null;
		if(!empty($meta['fields'])) {
			foreach($meta['fields'] as $field_properties) {
// echo '[JEAN get_field_proxy[field_properties='.print_r($field_properties, true).']'.$this->id.']'."\n";
				if($field_properties['id'] == $this->id) {
					$properties = $field_properties;
					break;
				}
			}
		}
		if(($properties !== null) && $value && is_array($value)) $properties = array_merge($properties, $value);
// echo '[JEAN get_field_proxy[properties='.print_r($properties, true).']]'."\n";
		if(empty($properties)) { // new form field -- create an empty field instance
			$project_id = 0;
			$feeds = GFAPI::get_feeds(null, $form_id, 'lassobridgeaddon');
			if(!is_wp_error($feeds) && !empty($feeds)) {
				$feed = $feeds[0];
				if($feed && isset($feed['meta']) && isset($feed['meta']['project_id']) && $feed['meta']['project_id']) $project_id = $feed['meta']['project_id'];
			}
// echo '[JEAN get_field_proxy[project_id='.print_r($project_id, true).']]'."\n";
			if($project_id) {
				$lasso_form_fields = $this->lasso_form_fields($project_id);
				$questions = array_values(preg_grep('/^\d+$/i', $lasso_form_fields));
				$field_id = $this->inputName;
				if(!$field_id) empty($questions) ? $lasso_form_fields[0] : $questions[0];
				$lasso_field_info = $this->lasso_field_info($project_id, $field_id);
// echo '[JEAN get_field_proxy[lasso_field_info='.print_r($lasso_field_info, true).']]'."\n";
				if(!$this->inputType) $this->inputType = $lasso_field_info['tag'];
				if(!empty($lasso_field_info['options'])) {
					$properties['choices'] = [];
					$value_field = $lasso_field_info['option']['value'];
					$name_field = $lasso_field_info['option']['name'];
					foreach($lasso_field_info['options'] as $option) {
						if(is_array($option)) $option = @json_decode(@json_encode($option));
						$properties['choices'][] = [ 'text' => $option->$name_field, 'value' => $option->$value_field ];
					}
					$properties['enableChoiceValue'] = true;
				}
			}
		}
		$properties['size'] = 'large';
		$properties['type'] = $this->inputType;
// echo '[JEAN get_field_proxy[properties=>'.print_r($properties, true).']]'."\n";
// exit();
		return GF_Fields::create($properties);
	}
	public function is_conditional_logic_supported() {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return false;
		return $proxy->is_conditional_logic_supported();
	}
	public function is_value_submission_array() {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return false;
		return $proxy->is_value_submission_array();
	}
	public function get_entry_inputs() {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return [];
// echo '[JEAN Q get_entry_inputs[inputs='.print_r($proxy->get_entry_inputs(), true).']]'."\n";
		return $proxy->get_entry_inputs();
	}
	public function get_value_save_entry( $value, $form, $input_name, $lead_id, $lead ) {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return null;
		return $proxy->get_value_save_entry( $value, $form, $input_name, $lead_id, $lead );
	}
	public function get_field_input($form, $value = '', $entry = null) {
// echo '[JEAN Q get_field_input[field type='.print_r($this->inputType, true).']]'."\n";
// echo '[JEAN Q get_field_input[field value='.print_r($value, true).']]'."\n";
		$proxy = $this->get_field_proxy($form['id'], $value);
// echo '[JEAN get_field_input[proxy='.print_r($proxy, true).']'.get_class($proxy).']'."\n";
// exit();
		if(!$proxy) return null;
		return $proxy->get_field_input($form, $value, $entry);
	}
	public function get_value_export($entry, $input_id='', $use_text=false, $is_csv=false) {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return null;
		$value = $proxy->get_value_export($entry, $input_id, $use_text, $is_csv);
		if($value && !empty($this->choices && method_exists($proxy, 'to_array'))) $value = $proxy->to_array($value);
		return $value;
	}
	public function get_choices( $value ) {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return [];
		return $proxy->get_choices($value);
	}
	public function get_value_entry_list( $value, $entry, $field_id, $columns, $form ) {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return null;
		return $proxy->get_value_entry_list($value, $entry, $field_id, $columns, $form);
	}
	public function get_value_entry_detail( $value, $currency = '', $use_text = false, $format = 'html', $media = 'screen' ) {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return null;
		return $proxy->get_value_entry_list($value, $currency, $use_text, $format, $media);
	}
	public function get_value_merge_tag( $value, $input_id, $entry, $form, $modifier, $raw_value, $url_encode, $esc_html, $format, $nl2br ) {
		$proxy = $this->get_field_proxy($this->formId);
		if(!$proxy) return null;
		return $proxy->get_value_entry_list($value, $input_id, $entry, $form, $modifier, $raw_value, $url_encode, $esc_html, $format, $nl2br);
	}
}
GF_Fields::register(new LB_GF_Question_Field());
