<?php
    /*
     * Plugin Name: Lasso Bridge Plugin
     * Plugin URI:  https://www.lassocrm.com/
     * Description: Bridge to Lasso CRM, via Gravity Forms or Contact Form plugins
     * Author:      Jean Le Clerc
     * Version:     1.8
     * Author URI:  https://mountainwebmedia.com/
     */
    if(!defined('ABSPATH')) exit; // Exit if accessed directly
    if(!defined('LB_PLUGIN_BASE_DIR')) {
        if(defined('LOCAL_NIBNUT') && LOCAL_NIBNUT) $path = '/Users/jean/Documents/nibnut/SideProjects/wp5box/wp-content/plugins/lasso-bridge';
        else $path = dirname(__FILE__);
        define('LB_PLUGIN_BASE_DIR', $path);
    }

    global $lb_plugin;
    if(defined('WPCF7_VERSION')) require_once(LB_PLUGIN_BASE_DIR.'/classes/lasso-contact-form-add-on.php');
    require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoSettings.php');

    define('LB_PLUGIN_VERSION', '1.8');

    if(!class_exists('LB_Plugin')) {
        class LB_Plugin {
            use LassoSettings;

			const SETTINGS_NAME = 'lb-plugin-settings';
            const SETTINGS_PAGE = 'lb-plugin-settings';
            const SETTING_TYPE_PAGE_MENU = 'page-menu';

            static protected $_instance;
            static public $token = 'lb-plugin';
            static public $lasso_projects = [];
            static public function instance(){
                if(is_null(LB_Plugin::$_instance)) LB_Plugin::$_instance = new LB_Plugin();
                return LB_Plugin::$_instance;
            }
            static public function install() {
                $plugin = LB_Plugin();

                /*
                $table_name = $wpdb->prefix.'wp_plugin_table';
                $charset_collate = $wpdb->get_charset_collate();
            
                $sql = "CREATE TABLE $table_name (
                    ...
                ) $charset_collate;";
            
                require_once(ABSPATH.'wp-admin/includes/upgrade.php');
                dbDelta($sql);
                */
                $plugin->upgrade_lasso_settings();

                update_option(LB_Plugin::$token.'-version', LB_PLUGIN_VERSION);
            }
            public function lasso_project($project_id, $api_key = null, $refresh = false) {
                if(!$project_id || !array_key_exists($project_id, LB_Plugin::$lasso_projects) || $refresh) {
                    if($project_id && !$api_key) {
                        $settings = $this->lasso_setting(null, $project_id);
                        if($settings) $api_key = $settings['api_key'];
                    }
                    $lasso_project = $api_key ? $this->api_call($api_key, 'projects/settings') : null;
                    if(!$lasso_project) return (object)[
                        'project' => (object)[ 'Id' => 0 ],
                        'websiteTracking' => [],
                        'rotations' => [],
                        'salesReps' => [],
                        'sourceTypes' => [],
                        'secondarySourceTypes' => [],
                        'ratings' => [],
                        'followUpProcesses' => [],
                        'questions' => [],
                        'autoReplyTemplates' => []
                    ];
                    if(!$project_id) $project_id = $lasso_project->project->projectId;
                    LB_Plugin::$lasso_projects[$project_id] = $lasso_project;
                }
                return LB_Plugin::$lasso_projects[$project_id];
            }
                    
            function __construct() {
                add_action('gform_loaded', array($this, 'gform_loaded'), 5);
                add_action('plugins_loaded', array($this, 'plugins_loaded'));
				add_action('wp_footer', array($this, 'wp_footer'));
            }
            public function plugins_loaded() {
                load_plugin_textdomain('lb-plugin-strings', false, dirname(plugin_basename(__FILE__)).'/languages/');
                
                if(class_exists('LassoContactFormAddOn')) LassoContactFormAddOn::bootstrap();
            }
            public function gform_loaded() {
                if(!method_exists('GFForms', 'include_addon_framework')) return;
                require_once(LB_PLUGIN_BASE_DIR.'/classes/lasso-gravity-forms-add-on.php');
                GFAddOn::register('LassoGravityFormsAddOn');
            }
            public function wp_footer() {
                $plugin_settings = $this->lasso_setting();
                $lasso_projects = [];
                if(!empty($plugin_settings)) {
                    foreach($plugin_settings as $project_id => $settings) {
                        $lasso_project = $this->lasso_project($project_id);
                        if(!!$lasso_project && isset($lasso_project->websiteTracking) && !empty($lasso_project->websiteTracking) && isset($settings['websiteTracking'])) $lasso_projects[] = $lasso_project;
                    }
                }
                if(!empty($lasso_projects)) {
                    include(dirname(__FILE__).'/templates/analytics-footer.php');
                }
            }

            public function asset_url($path) {
                return plugins_url($path, __FILE__);
            }
        }
        if(!isset($lb_plugin)) $lb_plugin = LB_Plugin::instance();
    }

    function LB_Plugin() {
        return LB_Plugin::instance();
    }
    add_action('plugins_loaded', 'LB_Plugin');
    register_activation_hook(__FILE__, array('LB_Plugin', 'install'));
    
?>