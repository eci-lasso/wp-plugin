<?php
    if(!$project_id) {
?>
<table class="form-table">
    <tbody>
        <tr>
            <th scope="row">
                <?php echo esc_html(__('Enter the project\'s API Key', 'lb-plugin-strings')); ?>
            </th>
            <td>
                <input type="text" value="" name="api_key" />
            </td>
        </tr>
    </tbody>
</table>
<?php
    } else {
?>
<table class="form-table">
    <tbody>
    <?php
        $lasso_form_fields = $this->lasso_setting_fields($project_id);
        foreach($lasso_form_fields as $setting_id) {
            if(($setting_id == 'api_key') || !isset($settings[$setting_id])) continue;
            $lasso_field_info = $this->lasso_field_info($project_id, $setting_id);
            $setting_value = $settings[$setting_id];
    ?>
        <tr>
            <th scope="row">
                <?php echo esc_html($lasso_field_info['label']); ?>
            </th>
            <td>
                <fieldset>
                    <?php
                    if(!!$lasso_field_info['description']) {
                    ?>
                    <legend class="screen-reader-text">
                        <?php echo $lasso_field_info['description']; ?>
                    </legend>
                    <?php
                    }
                    if($lasso_field_info['tag'] == 'checkbox') {
                    ?>
                    <label for="<?php echo $setting_id; ?>">
                        <input
                            type="checkbox"
                            name="<?php echo $setting_id; ?>"
                            id="<?php echo $setting_id; ?>"
                            value="1"
                            <?php echo !!$setting_value ? ' checked="checked"' : ''; ?>
                        />
                    </label>
                    <?php
                    } else {
                        $value_field = $lasso_field_info['option']['value'];
                        $name_field = $lasso_field_info['option']['name'];
                        $name = $setting_id;
                        $is_multi_select = ($lasso_field_info['tag'] == 'multi_select');
                        if($is_multi_select) $name .= '[]';
                    ?>
                    <select name="<?php echo $name; ?>"<?php echo $is_multi_select ? ' multiple' : ''; ?>>
                        <?php
                        if(!$is_multi_select) {
                            if(!isset($lasso_field_info['required']) || !$lasso_field_info['required']) {
                        ?>
                        <option value="0"<?php echo !$setting_value ? ' selected="selected"' : ''; ?>><?php echo esc_html(__('Set by a form field', 'lb-plugin-strings')); ?></option>
                        <?php
                            }
                            foreach($lasso_field_info['options'] as $option) {
                        ?>
                            <option value="<?php echo $option->$value_field; ?>"<?php echo (($setting_value == $option->$value_field) ? ' selected="selected"' : ''); ?>><?php echo $option->$name_field; ?></option>
                        <?php
                            }
                        } else {
                            foreach($lasso_field_info['options'] as $option) {
                        ?>
                            <option value="<?php echo $option->$value_field; ?>"<?php echo (in_array($option->$value_field, $setting_value) ? ' selected="selected"' : ''); ?>><?php echo $option->$name_field; ?></option>
                        <?php
                            }
                        }
                        ?>
                    </select>
                    <?php
                    }
                    ?>
                </fieldset>
            </td>
        </tr>
    <?php
    }
    ?>
    </tbody>
</table>
<?php } ?>