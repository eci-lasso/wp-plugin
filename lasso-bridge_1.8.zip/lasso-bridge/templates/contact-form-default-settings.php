<table class="form-table">
    <tbody>
        <?php
        if($this->is_active()) {
// echo '[JEAN plugin_settings['.print_r($plugin_settings, true).']]';
            foreach($plugin_settings as $project_id => $settings) {
                $lasso_project = $this->lasso_project($project_id, $settings['api_key']);
// echo '[JEAN settings['.print_r($lasso_project, true).']'.$project_id.']';
        ?>
        <tr>
            <td>
                <form
                    method="post"
                    action="<?php echo esc_url( $this->menu_page_url('action=setup')); ?>"
                    class="lasso-settings meta-box-sortables"
                >
                    <?php wp_nonce_field('wpcf7-lasso-setup'); ?>
                    <div id="lasso-project-<?php echo $project_id; ?>" class="lasso-postbox">
                        <div class="lasso-postbox-header">
                            <h2>
                                <div>
                                    <?php
                                        echo $lasso_project->project->name;
                                        echo '<p class="description"><small>'.esc_html($this->mask_value($settings['api_key'], 4, 4)).'</small></p>';
                                        echo sprintf(
                                            '<input type="hidden" value="%s" name="project_id" />',
                                            esc_attr($project_id)
                                        );
                                    ?>
                                </div>
                                <div class="handle-actions">
                                    <button type="button" aria-expanded="true">
                                        <span class="screen-reader-text">Toggle panel: <?php echo $lasso_project->project->name; ?></span>
                                        <span class="toggle-indicator" aria-hidden="true"></span>
                                    </button>
                                </div>                            
                            </h2>
                        </div>
                        <div class="lasso-postbox-inside">
                            <?php
                                include(dirname(__FILE__).'/settings.php');
                                submit_button(
                                    _x('Save Changes', 'API keys', 'lb-plugin-strings'),
                                    'primary'
                                );
                                submit_button(
                                    _x('Unlink this project', 'API keys', 'lb-plugin-strings'),
                                    'small',
                                    'reset'
                                );
                            ?>
                        </div>
                    </div>
                </form>
            </td>
        </tr>
        <?php   
            }
        }
        ?>
    </tbody>
</table>
<table class="lasso-settings-new-api-key">
    <tbody>
        <tr>
            <th scope="row">
                <?php echo esc_html(__('API Key', 'lb-plugin-strings')); ?>
            </th>
            <td>
                <form
                    method="post"
                    action="<?php echo esc_url( $this->menu_page_url('action=setup')); ?>"
                    class="lasso-settings"
                >
                    <?php wp_nonce_field('wpcf7-lasso-setup'); ?>
                    <input type="text" value="" name="api_key" />
                </form>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <div class="columns">
                    <div class="column">
                        <button type="button" class="button button-cancel"><?php echo esc_html(__('Cancel', 'lb-plugin-strings')); ?></button>
                    </div>
                    <div class="column">
                        <?php if($this->is_active()) { ?>
                        <button type="button" id="lasso-add-api-key" class="button"><?php echo esc_html(__('Link a new project', 'lb-plugin-strings')); ?></button>
                        <?php } else { ?>
                        <button type="button" id="lasso-add-api-key" class="button button-primary"><?php echo esc_html(__('Link a new project', 'lb-plugin-strings')); ?></button>
                        <?php } ?>
                    </div>
                </div>
            </td>
        </tr>
    </tbody>
</table>
