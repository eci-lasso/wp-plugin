<?php
if(!class_exists('GFForms')) die();
require_once(LB_PLUGIN_BASE_DIR.'/traits/LassoGravityFormField.php');

class LB_GF_Hidden_Field extends GF_Field_Hidden {
    use LassoGravityFormField;

    public $type = 'lb_hidden';
    // $this->inputName

    public function get_form_editor_field_description() {
        return esc_attr__('Add a pre-formatted hidden field to send to Lasso', 'lb-plugin-strings');
    }
}
